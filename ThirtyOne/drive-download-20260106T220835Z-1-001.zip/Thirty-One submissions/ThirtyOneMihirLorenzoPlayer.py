from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneMihirLorenzoPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Mihir & Lorenzo"
        self.turn_count = 0  # track our turns

    # --------------------------------------------------
    # Card / Hand Utilities
    # --------------------------------------------------

    def get_card_value(self, card):
        if card.rank.name in ['JACK', 'QUEEN', 'KING']:
            return 10
        elif card.rank.name == 'ACE':
            return 11
        else:
            return int(card.rank.value)

    def get_hand_value(self, hand):
        suit_totals = {}
        for card in hand:
            suit_totals.setdefault(card.suit, 0)
            suit_totals[card.suit] += self.get_card_value(card)
        return max(suit_totals.values()) if suit_totals else 0

    def get_best_suit(self, hand):
        suit_totals = {}
        for card in hand:
            suit_totals.setdefault(card.suit, 0)
            suit_totals[card.suit] += self.get_card_value(card)
        return max(suit_totals, key=suit_totals.get)

    # --------------------------------------------------
    # Opponent Threat Estimation (from discard history)
    # --------------------------------------------------

    def estimate_opponent_threat(self, move_storage):
        """
        Heuristic:
        - Many high cards discarded recently => opponents likely strong
        """
        threat = 0

        recent_moves = move_storage[-6:] if move_storage else []
        for move in recent_moves:
            if isinstance(move, ThirtyOneDiscardMove):
                if self.get_card_value(move.card) >= 9:
                    threat += 1

        return threat  # 0–5 scale

    # --------------------------------------------------
    # Knock Logic (your empirically-derived thresholds)
    # --------------------------------------------------

    def knock_threshold_for_turn(self, turn):
        thresholds = {
            1: 20,
            2: 23,
            3: 25,
            4: 26,
            5: 27,
            6: 28,
        }
        return thresholds.get(turn, 27)

    def should_knock(self, hand, move_storage):
        hand_value = self.get_hand_value(hand)
        threat = self.estimate_opponent_threat(move_storage)

        base_threshold = self.knock_threshold_for_turn(self.turn_count)

        # Against 2 opponents, knock slightly earlier if danger is high
        # if threat >= 3:
        #     base_threshold -= 1

        return hand_value >= base_threshold

    # --------------------------------------------------
    # Draw Decision
    # --------------------------------------------------

    def evaluate_hand_with_card(self, hand, new_card):
        test_hand = list(hand) + [new_card]
        best_value = 0

        for card_to_remove in test_hand:
            remaining = [c for c in test_hand if c != card_to_remove]
            best_value = max(best_value, self.get_hand_value(remaining))

        return best_value

    def choose_draw_move(self, cards, top_discard, move_storage):
        self.turn_count += 1
        current_value = self.get_hand_value(cards)

        # --- KNOCK DECISION ---
        if self.should_knock(cards, move_storage):
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        # --- DISCARD vs DECK ---
        if top_discard and top_discard != 0:
            value_with_discard = self.evaluate_hand_with_card(cards, top_discard)

            if value_with_discard > current_value:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    # --------------------------------------------------
    # Discard Decision
    # --------------------------------------------------

    def choose_discard_move(self, cards, top_discard, move_storage):
        """
        Discard to maximize future suit concentration.
        """
        if len(cards) <= 3:
            return cards[0]

        best_suit = self.get_best_suit(cards)

        # Prefer discarding lowest-value card NOT in best suit
        non_best_suit_cards = [
            c for c in cards if c.suit != best_suit
        ]

        if non_best_suit_cards:
            return min(non_best_suit_cards, key=self.get_card_value)

        # Fallback: discard lowest-value card
        return min(cards, key=self.get_card_value)
