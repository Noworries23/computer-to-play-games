from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneMaggiePlayer():
    def __init__(self):
        super().__init__()
        self.name = "Maggie"
        self.turn = 1

    def choose_draw_move(self, cards, top_discard, move_storage):
        if self.turn <= 5 and self.turn % 2 == 0:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
        elif self.turn <= 5 and self.turn % 2 != 0:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK
        else:
            return ThirtyOneDrawChoiceMove.Choice.KNOCK
        # Example strategy: always draw from the deck

    def choose_discard_move(self, cards, top_discard, move_storage):
        self.turn += 1
        card_to_discard = cards[1]
        return card_to_discard