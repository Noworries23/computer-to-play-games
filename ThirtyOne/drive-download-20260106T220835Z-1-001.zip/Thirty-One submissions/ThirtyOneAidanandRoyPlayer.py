from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.Card import Card
from collections import defaultdict
import random

class ThirtyOneAidanandRoyPlayer:
    def __init__(self):
        self.name = "Aidan and Roy"
        self.locked_suit = None
        self.turn_count = 0
        self.seen_discards = []
        self.debug = False 

        self.CARD_VALUES = {Card.Rank.ACE:11, Card.Rank.JACK:10, Card.Rank.QUEEN:10, Card.Rank.KING:10}
        for r in [Card.Rank.TWO, Card.Rank.THREE, Card.Rank.FOUR, Card.Rank.FIVE,
                  Card.Rank.SIX, Card.Rank.SEVEN, Card.Rank.EIGHT, Card.Rank.NINE, Card.Rank.TEN]:
            self.CARD_VALUES[r] = int(r.value)

        self.simulations = 100  # Number of Monte Carlo rollouts

    def get_card_value(self, card):
        return self.CARD_VALUES[card.rank]

    def analyze_hand(self, cards):
        hand_total = defaultdict(int)
        card_count = defaultdict(int)
        cards_by_suit = defaultdict(list)
        has_ace = defaultdict(bool)

        for card in cards:
            s = card.suit
            v = self.get_card_value(card)
            hand_total[s] += v
            card_count[s] += 1
            cards_by_suit[s].append(card)
            if card.rank == Card.Rank.ACE:
                has_ace[s] = True

        sorted_suits = sorted(hand_total.items(), key=lambda x: x[1], reverse=True)
        best_suit = sorted_suits[0][0] if sorted_suits else None
        best_total = sorted_suits[0][1] if sorted_suits else 0
        second_suit = sorted_suits[1][0] if len(sorted_suits) > 1 else None
        second_total = sorted_suits[1][1] if len(sorted_suits) > 1 else 0

        return {
            'hand_total': hand_total,
            'card_count': card_count,
            'cards_by_suit': cards_by_suit,
            'has_ace': has_ace,
            'best_suit': best_suit,
            'best_total': best_total,
            'second_suit': second_suit,
            'second_total': second_total
        }

    def get_unseen_cards(self, cards, move_storage, top_discard):
        unseen = {}
        for s in Card.Suit:
            for r in Card.Rank:
                unseen[(s,r)] = 1
        for c in cards:
            unseen.pop((c.suit, c.rank), None)
        for c in self.seen_discards:
            unseen.pop((c.suit, c.rank), None)
        if top_discard and top_discard != 0:
            unseen.pop((top_discard.suit, top_discard.rank), None)
        return unseen

    def observe_discard(self, card):
        self.seen_discards.append(card)

    def monte_carlo_hand_ev(self, cards, unseen_cards):
        total_ev = 0
        unseen_list = list(unseen_cards.keys())

        for _ in range(self.simulations):
            sim_cards = cards[:]
            sim_unseen = unseen_list[:]
            random.shuffle(sim_unseen)

            suit_totals = defaultdict(int)
            for c in sim_cards:
                suit_totals[c.suit] += self.get_card_value(c)

            for c_suit, c_rank in sim_unseen[:3]: 
                suit_totals[c_suit] += self.CARD_VALUES[c_rank]

            total_ev += max(suit_totals.values())

        return total_ev / self.simulations

    def should_knock(self, hand_analysis, unseen_cards):
        best_total = hand_analysis['best_total']
        best_suit = hand_analysis['best_suit']

        if best_total >= 31:
            return True
        if best_total >= 27:
            return True

        ev = self.monte_carlo_hand_ev(hand_analysis['cards_by_suit'][best_suit], unseen_cards)
        if best_total >= 24 and ev - best_total < 1.5:
            return True

        return False

    def choose_draw_move(self, cards, top_discard, move_storage):
        self.turn_count += 1
        hand_analysis = self.analyze_hand(cards)
        unseen_cards = self.get_unseen_cards(cards, move_storage, top_discard)

        if self.should_knock(hand_analysis, unseen_cards):
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        # Monte Carlo EV for top discard vs deck
        take_discard = False
        if top_discard and top_discard != 0:
            discard_suit = top_discard.suit
            temp_hand = cards + [top_discard]
            ev_discard = self.monte_carlo_hand_ev(temp_hand, unseen_cards)
            ev_deck = self.monte_carlo_hand_ev(cards, unseen_cards)
            if ev_discard > ev_deck:
                take_discard = True

        if take_discard:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    # ------------------------------
    # Discard logic
    # ------------------------------

    def choose_discard_card(self, cards, hand_analysis, unseen_cards):
        best_suit = hand_analysis['best_suit']
        discard_scores = []

        for card in cards:
            score = 0
            if card.suit == best_suit:
                score = 9999  # Never discard best suit
            else:
                # Penalize giving opponent high cards
                val = self.get_card_value(card)
                score = val
                if card.rank == Card.Rank.ACE:
                    score += 10
            discard_scores.append((card, score))

        discard_scores.sort(key=lambda x: x[1])
        return discard_scores[0][0]

    def choose_discard_move(self, cards, top_discard, move_storage):
        hand_analysis = self.analyze_hand(cards)
        unseen_cards = self.get_unseen_cards(cards, move_storage, top_discard)

        card_to_discard = self.choose_discard_card(cards, hand_analysis, unseen_cards)
        self.observe_discard(card_to_discard)
        return card_to_discard
