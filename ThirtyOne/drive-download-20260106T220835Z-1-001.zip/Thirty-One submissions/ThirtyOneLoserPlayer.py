from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove, ThirtyOneDiscardMove
from ThirtyOne.Card import Card

class ThirtyOneSimonPlayer:
    def __init__(self):
        self.name = "Simon"
        self.preferred_suit = None
        self.seen = {s: set() for s in Card.Suit}
        self.last_log_index = 0

    def _card_value(self, card):
        r = card.rank.value
        if r == 1:
            return 11
        if r >= 11:
            return 10
        return r

    def _rank_value(self, rank):
        r = rank.value
        if r == 1:
            return 11
        if r >= 11:
            return 10
        return r

    def _suit_totals(self, cards):
        totals = {"CLUBS": 0, "DIAMONDS": 0, "SPADES": 0, "HEARTS": 0}
        for card in cards:
            totals[card.suit.name] += self._card_value(card)
        return totals

    def _hand_best_total(self, cards):
        totals = self._suit_totals(cards)
        return max(totals.values()) if totals else 0

    def _phase(self, move_storage):
        n = len(move_storage) if move_storage is not None else 0
        if n < 4:
            return "EARLY"
        elif n < 8:
            return "MID"
        else:
            return "LATE"

    def _is_high_card(self, card):
        return self._card_value(card) >= 10

    def _update_seen(self, cards, top_discard, move_storage):
        for c in cards:
            self.seen[c.suit].add(c.rank)
        if top_discard not in (None, 0):
            self.seen[top_discard.suit].add(top_discard.rank)
        if move_storage is None:
            return
        for i in range(self.last_log_index, len(move_storage)):
            line = move_storage[i]
            if "discarded " in line:
                part = line.split("discarded ", 1)[1].strip()
                if part.endswith("."):
                    part = part[:-1]
                if " of " in part:
                    rank_str, suit_str = part.split(" of ")
                    rank_name = rank_str.upper()
                    suit_name = suit_str.upper()
                    if rank_name in Card.Rank.__members__ and suit_name in Card.Suit.__members__:
                        rank = Card.Rank[rank_name]
                        suit = Card.Suit[suit_name]
                        self.seen[suit].add(rank)
        self.last_log_index = len(move_storage)

    def _remaining_ranks_in_suit(self, suit):
        all_ranks = set(Card.Rank)
        return all_ranks - self.seen[suit]

    def _suit_potential(self, suit_name, current_total):
        suit = Card.Suit[suit_name]
        remaining = self._remaining_ranks_in_suit(suit)
        values = sorted((self._rank_value(r) for r in remaining), reverse=True)
        add = sum(values[:2])
        potential = current_total + add
        if potential > 31:
            potential = 31
        return potential

    def _someone_knocked(self, move_storage):
        if move_storage is None:
            return False
        for line in move_storage:
            if "has knocked." in line:
                return True
        return False

    def choose_draw_move(self, cards, top_discard, move_storage):
        self._update_seen(cards, top_discard, move_storage)
        phase = self._phase(move_storage)
        current_totals = self._suit_totals(cards)
        current_best_suit = max(current_totals, key=current_totals.get)
        current_best_value = current_totals[current_best_suit]
        if self.preferred_suit is None and current_best_value >= 17:
            self.preferred_suit = current_best_suit
        hand_best = self._hand_best_total(cards)
        knock_blocked = self._someone_knocked(move_storage)
        if not knock_blocked and phase != "EARLY":
            best_potential = self._suit_potential(current_best_suit, current_best_value)
            if hand_best >= 21 and best_potential - hand_best <= 3:
                return ThirtyOneDrawChoiceMove.Choice.KNOCK
        simulated_cards = cards + [top_discard]
        simulated_totals = self._suit_totals(simulated_cards)
        simulated_best_suit = max(simulated_totals, key=simulated_totals.get)
        simulated_best_value = simulated_totals[simulated_best_suit]
        discard_value = self._card_value(top_discard)
        discard_suit = top_discard.suit.name
        immediate_gain = simulated_best_value - current_best_value
        if phase == "EARLY":
            if immediate_gain > 0:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
            if self._is_high_card(top_discard):
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK
        target_suit = self.preferred_suit or current_best_suit
        current_target_total = current_totals.get(target_suit, 0)
        simulated_target_total = simulated_totals.get(target_suit, 0)
        target_gain = simulated_target_total - current_target_total
        if phase == "MID":
            if discard_suit == target_suit and target_gain > 0:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
            if self._is_high_card(top_discard) and discard_value == 11 and immediate_gain > 0:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK
        if phase == "LATE":
            if discard_suit == target_suit and target_gain > 0:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK
        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        self._update_seen(cards, top_discard, move_storage)
        phase = self._phase(move_storage)
        totals = self._suit_totals(cards)
        potentials = {}
        for suit_name in ["CLUBS", "DIAMONDS", "SPADES", "HEARTS"]:
            potentials[suit_name] = self._suit_potential(suit_name, totals.get(suit_name, 0))
        strongest_suit = max(potentials, key=potentials.get)
        if self.preferred_suit is None:
            self.preferred_suit = strongest_suit
        else:
            if phase != "EARLY":
                strongest_suit = self.preferred_suit
        off_suit_cards = [c for c in cards if c.suit.name != strongest_suit]
        if len(off_suit_cards) == 0:
            return min(cards, key=lambda c: self._card_value(c))
        candidates = off_suit_cards
        if phase == "EARLY":
            non_high = [c for c in candidates if not self._is_high_card(c)]
            if non_high:
                candidates = non_high
        discard_card = min(candidates, key=lambda c: self._card_value(c))
        return discard_card
