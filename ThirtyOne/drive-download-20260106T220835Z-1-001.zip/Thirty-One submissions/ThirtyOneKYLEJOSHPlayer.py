from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove
import random

class ThirtyOneYOURNAMEPlayer():
    #counts = {
    #    CLUBcount: 0,
    #    DIAcount: 0,
    #    SPADEcount: 0,
    #    HEARTCount: 0
    #}

    def __init__(self):
        super().__init__()
        self.name = "Josh"

    def choose_draw_move(self, cards, top_discard, move_storage):
        """
        for i in range(3):
            if cards[i].suit.name == "CLUBS"
                CLUBcount += 1
            elif cards[i].suit.name == "DIAMONDS"
                DIAcount += 1
            elif cards[i].suit.name == "SPADES"
                SPADEcount += 1
            elif cards[i].suit.name == "HEARTS"
                HEARTcount += 1
        """
        choice = random.randint(0,2)

        if choice == 0:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK
        elif choice == 1:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
        else:
            returnThirtyOneDrawChoiceMove.Choice.KNOCK
        # Example strategy: always draw from the deck

    def choose_discard_move(self, cards, top_discard, move_storage):



        # Example strategy: discard the first card in hand
        card_to_discard = cards[random.randint(0,3)]
        return card_to_discard

