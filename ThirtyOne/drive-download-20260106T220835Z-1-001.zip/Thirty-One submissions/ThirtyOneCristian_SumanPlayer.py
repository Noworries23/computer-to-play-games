from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove
from ThirtyOne.Card import Card

class ThirtyOneCristian_SumanPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Cristian + Suman"

    def choose_draw_move(self, cards, top_discard, move_storage):
        # Decide whether to take the top discard or draw from deck / knock.
        # Helper to compute card and hand values consistent with Board logic.
        def _card_value(card):
            if card is None:
                return 0
            if card.rank.name in ['JACK', 'QUEEN', 'KING']:
                return 10
            if card.rank.name == 'ACE':
                return 11
            return int(card.rank.value)

        def _hand_value(hand):
            suit_totals = {}
            for c in hand:
                if c is None:
                    continue
                suit = c.suit
                suit_totals[suit] = suit_totals.get(suit, 0) + _card_value(c)
            return max(suit_totals.values()) if suit_totals else 0

        current_value = _hand_value(cards)

        # If there's a discard card, check if swapping it for any card improves hand value
        if top_discard is not None:
            for i in range(len(cards)):
                new_hand = list(cards)
                new_hand[i] = top_discard
                if _hand_value(new_hand) > current_value:
                    return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        # Otherwise, follow original threshold-based behaviour
        if current_value >= 22:
            return ThirtyOneDrawChoiceMove.Choice.KNOCK
        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        # If the hand contains cards of mixed suits, discard a card whose suit
        # does not match the suit of the majority of cards. If all cards share
        # the same suit, discard the lowest-value card.
        if not cards:
            return None

        # helper: map card to game value (Ace=11, face cards=10, others=rank number)
        def _card_value(card):
            try:
                rank = card.rank
            except AttributeError:
                return 0
            if rank == Card.Rank.ACE:
                return 11
            if rank in (Card.Rank.JACK, Card.Rank.QUEEN, Card.Rank.KING):
                return 10
            return rank.value

        # count suits
        suit_counts = {}
        for c in cards:
            suit_counts[c.suit] = suit_counts.get(c.suit, 0) + 1

        # find majority suit count
        max_count = max(suit_counts.values())

        # collect candidates whose suit is not the majority suit
        off_suit_candidates = [c for c in cards if suit_counts.get(c.suit, 0) < max_count]

        if off_suit_candidates:
            # discard the lowest-value off-suit card
            discard_card = min(off_suit_candidates, key=_card_value)
            return discard_card

        # all cards share the same suit (or tie); discard the lowest-value card
        discard_card = min(cards, key=_card_value)
        return discard_card
        



        


