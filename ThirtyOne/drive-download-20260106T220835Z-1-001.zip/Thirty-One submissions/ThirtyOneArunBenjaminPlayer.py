from __future__ import annotations

from typing import List, Optional, Dict, Tuple
from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.Card import Card


class ThirtyOneArunBenjaminPlayer:
    def __init__(self):
        super().__init__()
        self.name = "Arun Benjamin"

    def choose_draw_move(self, cards: List[Card], top_discard: Optional[Card], move_storage: List[str]):
        if top_discard == 0:
            top_discard = None

        current_best = self._best_hand_value(cards)
        if current_best >= 31:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

        if self._should_knock(cards, move_storage):
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        if top_discard is None:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

        best_after_take, _ = self._best_value_after_taking(cards, top_discard)

        if best_after_take >= current_best + 2:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
        if best_after_take >= 27 and best_after_take > current_best:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        target_suit = self._target_suit(cards)
        if top_discard.suit == target_suit and best_after_take > current_best:
            if self._card_value(top_discard) >= 10 or current_best <= 16:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards: List[Card], top_discard: Optional[Card], move_storage: List[str]) -> Card:
        if top_discard == 0:
            top_discard = None

        opponent_suit_pressure = self._estimate_suit_pressure(move_storage)

        best_keep_value = -1
        best_discards: List[Card] = []

        for c in cards:
            kept = [x for x in cards if x is not c]
            v = self._best_hand_value(kept)
            if v > best_keep_value:
                best_keep_value = v
                best_discards = [c]
            elif v == best_keep_value:
                best_discards.append(c)

        if len(best_discards) == 1:
            return best_discards[0]

        target = self._target_suit([x for x in cards])
        off_target = [c for c in best_discards if c.suit != target]
        if off_target:
            best_discards = off_target

        if len(best_discards) == 1:
            return best_discards[0]

        def danger_score(card: Card) -> Tuple[int, int, int, int]:
            v = self._card_value(card)
            ten_like = 1 if v == 10 else 0
            ace_like = 1 if v == 11 else 0
            suit_pressure = opponent_suit_pressure.get(card.suit, 0)
            return (v, ten_like, ace_like, suit_pressure)

        best_discards.sort(key=danger_score)
        return best_discards[0]

    @staticmethod
    def _card_value(card: Card) -> int:
        if card.rank.name in ["JACK", "QUEEN", "KING"]:
            return 10
        if card.rank.name == "ACE":
            return 11
        return int(card.rank.value)

    def _suit_totals(self, cards: List[Card]) -> Dict[Card.Suit, int]:
        totals: Dict[Card.Suit, int] = {}
        for c in cards:
            totals[c.suit] = totals.get(c.suit, 0) + self._card_value(c)
        return totals

    def _best_hand_value(self, cards: List[Card]) -> int:
        totals = self._suit_totals(cards)
        return max(totals.values()) if totals else 0

    def _target_suit(self, cards: List[Card]) -> Card.Suit:
        totals = self._suit_totals(cards)
        if not totals:
            return Card.Suit.CLUBS

        best = max(totals.values())
        candidates = [s for s, v in totals.items() if v == best]
        if len(candidates) == 1:
            return candidates[0]

        counts: Dict[Card.Suit, int] = {}
        for c in cards:
            counts[c.suit] = counts.get(c.suit, 0) + 1
        candidates.sort(key=lambda s: counts.get(s, 0), reverse=True)
        return candidates[0]

    def _best_value_after_taking(self, cards: List[Card], take: Card) -> Tuple[int, Card]:
        four = list(cards) + [take]
        best_val = -1
        best_discard = four[0]
        for c in four:
            kept = [x for x in four if x is not c]
            v = self._best_hand_value(kept)
            if v > best_val:
                best_val = v
                best_discard = c
        return best_val, best_discard

    def _should_knock(self, cards: List[Card], move_storage: List[str]) -> bool:
        h = self._best_hand_value(cards)
        if h >= 28:
            return True

        signals = self._log_signals(move_storage)
        turns = signals["discard_events"]
        high_discards = signals["high_discards"]
        shuffles = signals["shuffles"]

        if h >= 27:
            if high_discards >= max(2, turns // 6):
                return True
            if turns >= 12:
                return True

        if h >= 26:
            if shuffles >= 1 and turns >= 10:
                return True
            if turns >= 16:
                return True

        return False

    def _log_signals(self, move_storage: List[str]) -> Dict[str, int]:
        discard_events = 0
        high_discards = 0
        shuffles = 0

        for line in move_storage:
            lower = line.lower()
            if "discarded" in lower:
                discard_events += 1
                if (
                    ("ace of " in lower)
                    or ("king of " in lower)
                    or ("queen of " in lower)
                    or ("jack of " in lower)
                    or ("ten of " in lower)
                ):
                    high_discards += 1
            elif "shuffled the deck" in lower:
                shuffles += 1

        return {
            "discard_events": discard_events,
            "high_discards": high_discards,
            "shuffles": shuffles,
        }

    def _estimate_suit_pressure(self, move_storage: List[str]) -> Dict[Card.Suit, int]:
        suit_discards = {
            Card.Suit.CLUBS: 0,
            Card.Suit.DIAMONDS: 0,
            Card.Suit.SPADES: 0,
            Card.Suit.HEARTS: 0,
        }
        total_discards = 0

        for line in move_storage:
            lower = line.lower()
            if "discarded" not in lower:
                continue
            total_discards += 1
            if " of clubs" in lower:
                suit_discards[Card.Suit.CLUBS] += 1
            elif " of diamonds" in lower:
                suit_discards[Card.Suit.DIAMONDS] += 1
            elif " of spades" in lower:
                suit_discards[Card.Suit.SPADES] += 1
            elif " of hearts" in lower:
                suit_discards[Card.Suit.HEARTS] += 1

        pressure: Dict[Card.Suit, int] = {}
        if total_discards == 0:
            for s in suit_discards:
                pressure[s] = 0
            return pressure

        max_d = max(suit_discards.values())
        min_d = min(suit_discards.values())

        if max_d == min_d:
            for s in suit_discards:
                pressure[s] = 0
            return pressure

        for s, d in suit_discards.items():
            pressure[s] = max_d - d

        return pressure
