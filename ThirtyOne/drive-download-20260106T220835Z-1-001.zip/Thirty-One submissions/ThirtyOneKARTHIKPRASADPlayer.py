from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove
import random
import time

class ThirtyOneKARTHIKPRASADPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Liquidate all Countries - C.H."
        self.first_turn = True
        self.prioritySuit = None;

    def get_card_value(self, card):
        if card.rank.name in ['JACK', 'QUEEN', 'KING']:
         return 10
        elif card.rank.name == 'ACE':
         return 11
        else:
            return int(card.rank.value)

    def get_hand_value(self, hand):
        suit_totals = {}
        for card in hand:
            suit = card.suit
            value = self.get_card_value(card)
            if suit not in suit_totals:
                suit_totals[suit] = 0
            suit_totals[suit] += value
        return max(suit_totals.values()) if suit_totals else 0


    def choose_draw_move(self, cards, top_discard, move_storage):
        # Example strategy: always draw from the deck
        current_value = self.get_hand_value(cards)
        
        if self.first_turn == True:
            if current_value >= 19 and not any("knocked" in s.lower() for s in move_storage):
                self.first_turn = False;
                print(random.choice(["Querying GPT...", "Consulting Claude...", "Asking Gemini..."]), end="", flush=True)
                time.sleep(2);
                print("Knocking...")
                time.sleep(1);
                return ThirtyOneDrawChoiceMove.Choice.KNOCK;
            else:

                for card in cards:
                    cardSuit = card.suit;
                    value = self.get_card_value(card)
                    if value == 11:
                        self.prioritySuit = cardSuit;
                    elif value == 10:
                        self.prioritySuit = cardSuit;
                    else:
                        pass;
                if self.prioritySuit == None:
                    if self.get_card_value(top_discard) >= 10:
                        self.prioritySuit = top_discard.suit;
                        self.first_turn = False;
                        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD;
                    else:
                        self.first_turn = False;
                        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK;
                else:
                    if top_discard.suit == self.prioritySuit:
                        self.first_turn = False;
                        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD;
                    else:
                        self.first_turn = False;
                        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK;
        elif current_value >= 22 and not any("knocked" in s.lower() for s in move_storage):
            print(random.choice(["Querying GPT...", "Consulting Claude...", "Asking Gemini..."]), end="", flush=True)
            time.sleep(2);
            print("Knocking...")
            time.sleep(1);
            return ThirtyOneDrawChoiceMove.Choice.KNOCK;
        elif self.prioritySuit == None:
            if self.get_card_value(top_discard) >= 10:
                self.prioritySuit = top_discard.suit;
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD;
            else:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK;
        else:
            if top_discard.suit == self.prioritySuit:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD;
            else:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK;






    def choose_discard_move(self, cards, top_discard, move_storage):
        #reassess priority suit 
        #count honors
        suit_honor_counts = {}
        for card in cards:
            value = self.get_card_value(card)
            if value >= 10:
                suit = card.suit
                suit_honor_counts[suit] = suit_honor_counts.get(suit, 0) + 1

        #if any suit has 2+ honors, make it priority suit 
        for suit, count in suit_honor_counts.items():
            if count >= 2:
                self.prioritySuit = suit
                break
        # if we have a priority suit keep all cards in it 
        if self.prioritySuit:
            #discard stuff not in priority suit 
            non_priority_cards = [c for c in cards if c.suit != self.prioritySuit]
            if non_priority_cards:
                #discard lowest value
                return min(non_priority_cards, key=lambda c: self.get_card_value(c))
            else:
                #all cards in priority suit so discard lowest 
                return min(cards, key=lambda c:self.get_card_value(c))
        # No priority suit yet - discard lowest value card overall
        return min(cards, key=lambda c: self.get_card_value(c))

