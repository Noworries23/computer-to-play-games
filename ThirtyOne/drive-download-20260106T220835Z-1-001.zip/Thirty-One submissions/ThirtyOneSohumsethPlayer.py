import random
from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneSohumsethPlayer():
    def __init__(self):
        self.name = "Sohumseth"

    def choose_draw_move(self, cards, top_discard, move_storage):
        if random.randint(1, 5) == 1:
            print("KNOCKS")
            return ThirtyOneDrawChoiceMove.Choice.KNOCK
            
        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        return cards[0]