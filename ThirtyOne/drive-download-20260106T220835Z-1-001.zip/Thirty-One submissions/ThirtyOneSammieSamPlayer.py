from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneSammieSamPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Sammie and Sam"

    def choose_draw_move(self, cards, top_discard, move_storage):
        # Initialize GameTracker to analyze game state
        tracker = GameTracker(move_storage, num_players=2, my_cards=cards)
        deck_stats = tracker.get_deck_stats()
        
        # Score current cards using CardScorer
        current_scorer = CardScorer(cards)
        current_score = current_scorer.get_max_score()
        best_suit = current_scorer.get_best_suit()
        
        #print(f"[DEBUG] {self.name} - Current hand: {[str(c) for c in cards]}")
        #print(f"[DEBUG] {self.name} - Current scores: {current_scorer.suit_totals}, max: {current_score}")
        #print(f"[DEBUG] {self.name} - Deck size: {deck_stats['current_deck_size']}, Unknown locations: {deck_stats['unknown_locations']}")

        # Score if we draw the top discard
        discard_scorer = CardScorer(cards + [top_discard])
        discard_improvement = discard_scorer.get_max_score() - current_score
        
        #print(f"[DEBUG] {self.name} - Top discard: {top_discard}")
        #print(f"[DEBUG] {self.name} - Discard scores: {discard_scorer.suit_totals}, max: {discard_scorer.get_max_score()}")
        #print(f"[DEBUG] {self.name} - Discard improvement: +{discard_improvement}")

        # Calculate expected value of drawing from deck
        helpful_cards = self._identify_helpful_cards(cards, current_scorer, tracker)
        deck_improvement_probability = self._estimate_deck_improvement(helpful_cards, tracker)
        
        #print(f"[DEBUG] {self.name} - Helpful cards available: {helpful_cards}")
        #print(f"[DEBUG] {self.name} - Deck improvement probability: {deck_improvement_probability:.2%}")

        # DECISION 1: Always take discard if it improves score
        if discard_improvement > 0:
            #print(f"[DEBUG] {self.name} - Decision: DRAW_FROM_DISCARD (improves by +{discard_improvement})")
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        # DECISION 2: Knock if score is very high (27+) or if deck has few helpful cards
        knock_threshold = self._calculate_knock_threshold(current_score, deck_improvement_probability, deck_stats)
        if current_score >= knock_threshold:
            #print(f"[DEBUG] {self.name} - Decision: KNOCK (score {current_score} >= threshold {knock_threshold})")
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        # DECISION 3: Draw from deck if there's potential for improvement
        if deck_improvement_probability > 0.15:  # At least 15% chance of improvement
            #print(f"[DEBUG] {self.name} - Decision: DRAW_FROM_DECK (good probability {deck_improvement_probability:.2%})")
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK
        
        # DECISION 4: If deck looks bad, knock if score is decent (23+)
        elif current_score >= 23:
            #print(f"[DEBUG] {self.name} - Decision: KNOCK (score {current_score}, low deck probability)")
            return ThirtyOneDrawChoiceMove.Choice.KNOCK
        
        # DECISION 5: Last resort - draw from deck anyway
        else:
            #print(f"[DEBUG] {self.name} - Decision: DRAW_FROM_DECK (default choice)")
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        # Initialize GameTracker to analyze game state
        tracker = GameTracker(move_storage, num_players=2, my_cards=cards)
        
        # Use CardScorer to analyze the hand
        scorer = CardScorer(cards)
        best_suit = scorer.get_best_suit()
        second_best_suit = self._get_second_best_suit(scorer)
        
        best_suit_name = {1: "HEARTS", 2: "DIAMONDS", 3: "CLUBS", 4: "SPADES"}[best_suit]
        #print(f"[DEBUG] {self.name} - Hand scores: {scorer.suit_totals}, best suit: {best_suit_name}")
        
        # Analyze each card's strategic value
        card_values = []
        for card in cards:
            strategic_value = self._calculate_card_strategic_value(card, scorer, tracker, best_suit, second_best_suit)
            card_values.append((card, strategic_value))
            #print(f"[DEBUG] {self.name} - {card}: strategic value = {strategic_value:.2f}")
        
        # Sort by strategic value (ascending) and discard the least valuable
        card_values.sort(key=lambda x: x[1])
        worst_card = card_values[0][0]
        
        #print(f"[DEBUG] {self.name} - Discarding: {worst_card} (lowest strategic value: {card_values[0][1]:.2f})")
        return worst_card
    
    def _identify_helpful_cards(self, cards, scorer, tracker):
        """Identify which cards would improve the hand and are potentially available"""
        helpful_cards = []
        best_suit = scorer.get_best_suit()
        current_score = scorer.get_max_score()
        
        # Check all possible cards in best suit
        for rank in range(1, 14):
            # Skip if we already have this card
            if any(c.suit.value == best_suit and c.rank.value == rank for c in cards):
                continue
            
            # Calculate if this card would improve score
            card_value = scorer.value_dict[rank]
            potential_score = scorer.suit_totals[best_suit] + card_value
            
            if potential_score > current_score:
                prob = tracker.estimate_deck_probability(best_suit, rank)
                if prob > 0:  # Card is potentially available
                    helpful_cards.append({
                        'suit': best_suit,
                        'rank': rank,
                        'value': card_value,
                        'probability': prob,
                        'improvement': potential_score - current_score
                    })
        
        return helpful_cards
    
    def _estimate_deck_improvement(self, helpful_cards, tracker):
        """Estimate probability of drawing a helpful card from deck"""
        if not helpful_cards:
            return 0.0
        
        deck_size = tracker.get_current_deck_size()
        if deck_size == 0:
            return 0.0
        
        # Sum probabilities of all helpful cards
        total_probability = sum(card['probability'] for card in helpful_cards)
        
        # Normalize by deck size
        return min(1.0, total_probability)
    
    def _calculate_knock_threshold(self, current_score, deck_probability, deck_stats):
        """Calculate dynamic knock threshold based on game state"""
        base_threshold = 27
        
        # Lower threshold if deck has few helpful cards
        if deck_probability < 0.1:
            base_threshold = 24
        elif deck_probability < 0.2:
            base_threshold = 26
        
        # Lower threshold if deck is running low
        if deck_stats['current_deck_size'] < 10:
            base_threshold -= 2
        
        # Always knock at 31
        if current_score >= 31:
            return 31
        
        return base_threshold
    
    def _get_second_best_suit(self, scorer):
        """Get the second best suit for strategic planning"""
        sorted_suits = sorted(scorer.suit_totals.items(), key=lambda x: x[1], reverse=True)
        return sorted_suits[1][0] if len(sorted_suits) > 1 else sorted_suits[0][0]
    
    def _calculate_card_strategic_value(self, card, scorer, tracker, best_suit, second_best_suit):
        """Calculate strategic value of keeping a card (higher = more valuable)"""
        value = 0.0
        card_points = scorer.value_dict[card.rank.value]
        
        # Value based on suit contribution
        if card.suit.value == best_suit:
            value += 100 + card_points  # High value for best suit cards
        elif card.suit.value == second_best_suit:
            value += 50 + card_points   # Medium value for second best
        else:
            value += card_points        # Low value for other suits
        
        # Bonus for high-value cards (Aces, face cards)
        if card_points >= 10:
            value += 10
        
        # Penalty if many cards of this card's suit are already discarded
        # (less likely to complete a good hand in that suit)
        discarded_in_suit = tracker.count_known_cards_by_suit(card.suit.value)
        value -= discarded_in_suit * 2
        
        # Check if keeping this card blocks potential good draws
        # If we're not in best suit and could draw better cards
        if card.suit.value != best_suit:
            remaining_best_suit_cards = 13 - len(scorer.get_cards_in_suit(best_suit)) - tracker.count_known_cards_by_suit(best_suit)
            if remaining_best_suit_cards > 3:  # Plenty of best suit cards still available
                value -= 20  # Penalty for holding non-best-suit card
        
        return value

# Counting Cards
class GameTracker():
    """Tracks game state by parsing move_storage to understand:
    - What cards opponents have drawn from discard
    - What cards have been discarded
    - Probability of cards being in deck vs opponent hands
    """
    
    def __init__(self, move_storage, num_players=2, my_cards=None):
        self.move_storage = move_storage
        self.num_players = num_players
        self.my_cards = my_cards if my_cards else []
        
        self.discarded_cards = []  # Cards we've seen in discard pile
        self.opponent_known_cards = {}  # {opponent_name: [cards]}
        self.deck_shuffled = False
        
        # Track deck state
        self.total_deck_size = 52
        self.cards_drawn_from_deck = 0
        self.cards_drawn_from_discard = 0
        
        # Initial deal: 3 cards per player + 1 to discard pile
        self.initial_cards_dealt = (3 * num_players) + 1
        
        self._parse_moves()
    
    def _parse_moves(self):
        """Parse move_storage to extract useful information"""
        for move in self.move_storage:
            # Track discarded cards
            if "discarded" in move:
                # Format: "PlayerName discarded Card(suit=HEARTS, rank=TEN)."
                card_info = self._extract_card_from_string(move)
                if card_info:
                    self.discarded_cards.append(card_info)
            
            # Track draws from deck
            elif "drew from deck" in move:
                self.cards_drawn_from_deck += 1
            
            # Track when opponent draws from discard (they have that card!)
            elif "drew from discard pile" in move:
                player_name = move.split(" drew from discard")[0]
                self.cards_drawn_from_discard += 1
                if len(self.discarded_cards) > 0:
                    # The top discard is what they drew
                    top_card = self.discarded_cards[-1]
                    if player_name not in self.opponent_known_cards:
                        self.opponent_known_cards[player_name] = []
                    self.opponent_known_cards[player_name].append(top_card)
            
            # Track deck shuffles (discard pile recycled into deck)
            elif "Shuffled the deck" in move:
                self.deck_shuffled = True
    
    def _extract_card_from_string(self, move_string):
        """Extract card information from a move string like 'discarded Card(...)'"""
        try:
            if "Card(" in move_string:
                # Extract the card representation
                card_start = move_string.index("Card(")
                card_end = move_string.index(")", card_start) + 1
                card_str = move_string[card_start:card_end]
                return card_str
        except:
            pass
        return None
    
    def get_discarded_cards(self):
        """Returns list of all discarded cards"""
        return self.discarded_cards
    
    def get_opponent_known_cards(self, opponent_name):
        """Returns list of cards known to be in opponent's hand"""
        return self.opponent_known_cards.get(opponent_name, [])
    
    def count_known_cards_by_suit(self, suit_value):
        """Count how many cards of a suit have been discarded or are known in opponent hands"""
        count = 0
        for card_str in self.discarded_cards:
            if f"suit={suit_value}" in card_str or self._suit_name_match(card_str, suit_value):
                count += 1
        
        for opponent_cards in self.opponent_known_cards.values():
            for card_str in opponent_cards:
                if f"suit={suit_value}" in card_str or self._suit_name_match(card_str, suit_value):
                    count += 1
        return count
    
    def _suit_name_match(self, card_str, suit_value):
        """Match suit value (1-4) to suit name in card string"""
        suit_names = {1: "HEARTS", 2: "DIAMONDS", 3: "CLUBS", 4: "SPADES"}
        return suit_names.get(suit_value, "") in card_str
    
    def count_known_cards_by_rank(self, rank_value):
        """Count how many cards of a rank have been discarded or are known"""
        count = 0
        rank_names = {1: "ACE", 11: "JACK", 12: "QUEEN", 13: "KING"}
        rank_str = rank_names.get(rank_value, str(rank_value))
        
        for card_str in self.discarded_cards:
            if f"rank={rank_str}" in card_str:
                count += 1
        
        for opponent_cards in self.opponent_known_cards.values():
            for card_str in opponent_cards:
                if f"rank={rank_str}" in card_str:
                    count += 1
        return count
    
    def get_current_deck_size(self):
        """Calculate how many cards are currently in the draw pile"""
        # Start with 52 cards
        # Subtract: initial deal (3 * num_players + 1 for discard)
        # Subtract: cards drawn from deck (adds to hands)
        # Add: cards drawn from discard (doesn't reduce deck)
        # Note: When cards are discarded, they leave hands but deck stays same
        
        current_deck = self.total_deck_size - self.initial_cards_dealt - self.cards_drawn_from_deck
        
        # If deck was shuffled, discard pile (except top card) was added back
        if self.deck_shuffled:
            # When shuffled, all but top discard card go back to deck
            current_deck += len(self.discarded_cards) - 1
        
        return max(0, current_deck)
    
    def get_cards_in_unknown_locations(self):
        """Get count of cards in unknown locations (deck + unknown opponent cards)"""
        # Cards in my hand
        my_card_count = len(self.my_cards)
        
        # Cards in discard pile (currently visible is 1, but we track all seen)
        discard_count = 1  # Only top card is in discard pile
        
        # Cards we know opponents have (from drawing from discard)
        known_opponent_count = sum(len(cards) for cards in self.opponent_known_cards.values())
        
        # Total cards in unknown locations = 52 - accounted cards
        accounted_for = my_card_count + discard_count + known_opponent_count
        
        return self.total_deck_size - accounted_for
    
    def estimate_deck_probability(self, suit_value, rank_value):
        """Estimate probability a specific card is still in the deck
        Returns value between 0 and 1"""
        # Check if this specific card has been seen
        suit_names = {1: "HEARTS", 2: "DIAMONDS", 3: "CLUBS", 4: "SPADES"}
        rank_names = {1: "ACE", 11: "JACK", 12: "QUEEN", 13: "KING"}
        suit_str = suit_names[suit_value]
        rank_str = rank_names.get(rank_value, str(rank_value))
        
        # Check if I have this card
        for card in self.my_cards:
            if card.suit.value == suit_value and card.rank.value == rank_value:
                return 0.0  # I have it, not in deck
        
        # Check if it's in discard pile
        for card_str in self.discarded_cards:
            if f"suit={suit_str}" in card_str and f"rank={rank_str}" in card_str:
                return 0.0  # In discard pile, not in deck
        
        # Check if opponent has it (drew from discard)
        for opponent_cards in self.opponent_known_cards.values():
            for card_str in opponent_cards:
                if f"suit={suit_str}" in card_str and f"rank={rank_str}" in card_str:
                    return 0.0  # Opponent has it, not in deck
        
        # Card hasn't been seen - calculate probability
        deck_size = self.get_current_deck_size()
        unknown_locations = self.get_cards_in_unknown_locations()
        
        if unknown_locations == 0:
            return 0.0
        
        # Probability = (cards in deck) / (cards in unknown locations)
        # This accounts for the fact that unseen cards could be in deck OR opponent hands
        probability = deck_size / unknown_locations if unknown_locations > 0 else 0.0
        
        return min(1.0, max(0.0, probability))
    
    def get_deck_stats(self):
        """Get detailed statistics about deck state for debugging"""
        return {
            'current_deck_size': self.get_current_deck_size(),
            'cards_drawn_from_deck': self.cards_drawn_from_deck,
            'cards_drawn_from_discard': self.cards_drawn_from_discard,
            'known_discards': len(self.discarded_cards),
            'known_opponent_cards': sum(len(cards) for cards in self.opponent_known_cards.values()),
            'deck_shuffled': self.deck_shuffled,
            'unknown_locations': self.get_cards_in_unknown_locations()
        }
    
    

class CardScorer():
    # matches card index to the score it gives
    value_dict = {1: 11, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10, 
                11: 10, 12: 10, 13: 10}
    
    def __init__(self, cards):
        super().__init__()
        self.cards = cards
        self.suits_dict = self._organize_by_suit()
        self.suit_totals = self._calculate_totals()
    
    def _organize_by_suit(self):
        """Organize cards by suit"""
        suits = {1: [], 2: [], 3: [], 4: []}
        for card in self.cards:
            suits[card.suit.value].append(card)
        # Sort cards within each suit by value (descending)
        for suit in suits:
            suits[suit].sort(key=lambda c: self.value_dict[c.rank.value], reverse=True)
        return suits
    
    def _calculate_totals(self):
        """Calculate total score for each suit"""
        totals = {1: 0, 2: 0, 3: 0, 4: 0}
        for suit, cards in self.suits_dict.items():
            totals[suit] = sum(self.value_dict[card.rank.value] for card in cards)
        return totals
    
    def get_cards_in_suit(self, suit):
        """Get all cards in a specific suit"""
        return self.suits_dict[suit]
    
    def get_best_suit(self):
        """Get the suit with the highest total score"""
        return max(self.suit_totals, key=self.suit_totals.get)
    
    def get_worst_suit(self):
        """Get the suit with the lowest total score"""
        return min(self.suit_totals, key=self.suit_totals.get)
    
    def get_max_score(self):
        """Get the maximum score across all suits"""
        return max(self.suit_totals.values())

