from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneLynnPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Lynn & Callie"

    def card_value(self, card):
        if card.rank.name in ['JACK', 'QUEEN', 'KING']:
            return 10
        elif card.rank.name == 'ACE':
            return 11
        return int(card.rank.value)

    def choose_draw_move(self, cards, top_discard, move_storage):

        if self.hand_value(cards) >= 26:
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        suits = [card.suit for card in cards]
        unique_suits = set(suits)

        # If all three suits are different and discard matches one suit → take it
        if len(unique_suits) == 3 and top_discard is not None:
            if top_discard.suit in unique_suits:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        # Otherwise draw from deck
        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        suits = [card.suit for card in cards]
        unique_suits = set(suits)

        if len(unique_suits) == 2:
            for card in cards:
                if suits.count(card.suit) == 1:
                    return card

        return min(cards, key=self.card_value)

