from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOne_Anthony_MacintoshPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Anthony_Macintosh"

    # ----------------------------
    # Utility / evaluation helpers
    # ----------------------------

    def card_value(self, card):
        if card.rank.name in ['JACK', 'QUEEN', 'KING']:
            return 10
        elif card.rank.name == 'ACE':
            return 11
        else:
            return int(card.rank.value)

    def get_hand_value(self, cards):
        suit_totals = {}
        for card in cards:
            suit_totals.setdefault(card.suit, 0)
            suit_totals[card.suit] += self.card_value(card)
        return max(suit_totals.values()) if suit_totals else 0
    
    def get_best_suit(self, cards):
        suit_totals = {}
        for card in cards:
            suit_totals.setdefault(card.suit, 0)
            suit_totals[card.suit] += self.card_value(card)
        return max(suit_totals, key=suit_totals.get)
    
    # ----------------------------
    # DRAW decision
    # ----------------------------

    def choose_draw_move(self, cards, top_discard, move_storage):
        current_value = self.get_hand_value(cards)

        class TurnCounter:
    
            def __init__(self, num_players):
                self.turn_number = 0
                self.num_players = num_players

    def advance(self):
        # Call once after every completed move
        self.turn_number += 1


    def rounds_elapsed(self):
        # Full table cycles completed
        return self.turn_number // self.num_players
    def should_knock(hand_value, turn_counter):
        rounds = turn_counter.rounds_elapsed()
        # Aggressive opening rule
        if rounds == 0 and hand_value >= 26:
            return True
        # Deterministic threshold ramp (less aggressive over time)
        threshold = min(29, 24 + rounds)
        return hand_value >= threshold



    # 2. Take discard if it improves best suit value
        for i in range(len(cards)):
            test_hand = cards[:]
            test_hand[i] = top_discard
            if self.get_hand_value(test_hand) > current_value:
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
    # 3. Otherwise draw from deck
        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK


    # ----------------------------
    # DISCARD decision
    # ----------------------------

    def choose_discard_move(self, cards, top_discard, move_storage):
        best_suit = self.get_best_suit(cards)

        # Prefer discarding lowest-value card NOT in best suit
        off_suit_cards = [c for c in cards if c.suit != best_suit]

        if off_suit_cards:
            return min(off_suit_cards, key=self.card_value)

        # If all cards are in best suit, discard lowest-value card
        return min(cards, key=self.card_value)
    
