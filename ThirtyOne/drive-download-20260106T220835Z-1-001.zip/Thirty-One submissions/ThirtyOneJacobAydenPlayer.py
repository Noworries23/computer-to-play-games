from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneJacobAydenPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Ayden Stahl and Jacob Holt"

    def _card_points(self, card):
        # Standard 31 scoring: Ace=11, Ten/Jack/Queen/King=10, others face value
        r = card.rank
        if r.name in ("TEN", "JACK", "QUEEN", "KING"):
            return 10
        if r.name == "ACE":
            return 11
        return r.value

    def _suit_totals(self, cards):
        totals = {}
        for c in cards:
            totals.setdefault(c.suit, 0)
            totals[c.suit] += self._card_points(c)
        return totals

    def choose_draw_move(self, cards, top_discard, move_storage):
        # Decide whether to draw the top discard, draw from deck, or knock.
        if top_discard is None:
            # If there's no visible discard, draw from deck or knock if strong
            current_best = max(self._suit_totals(cards).values()) if cards else 0
            if current_best >= 27:
                return ThirtyOneDrawChoiceMove.Choice.KNOCK
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

        current_totals = self._suit_totals(cards)
        current_best = max(current_totals.values()) if current_totals else 0

        # Evaluate totals if we take the discard
        simulated = cards + [top_discard]
        new_totals = self._suit_totals(simulated)
        new_best = max(new_totals.values()) if new_totals else 0

        # Count cards of same suit currently and if taking discard increases count to 3
        same_suit_count = sum(1 for c in cards if c.suit == top_discard.suit)
        will_have_three = (same_suit_count + 1) >= 3

        # If we're already strong, consider knocking
        if current_best >= 28:
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        # Take the discard if it clearly improves our best suit
        if new_best >= current_best + 3:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        # Take discard if it completes/strengthens a 3-card suit or is a high-value card
        if will_have_three or self._card_points(top_discard) >= 10 and same_suit_count >= 1:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        # Otherwise draw from deck
        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        # Choose the discard by simulating removing each card and preferring the
        # removal that leaves the highest best-suit total. Tiebreak using suit counts
        # (prefer removing singletons) and lower point value.
        best_discard = None
        best_remaining_score = -1
        best_tiebreak = None

        current_best = max(self._suit_totals(cards).values()) if cards else 0

        for candidate in cards:
            remaining = [c for c in cards if c is not candidate]
            totals = self._suit_totals(remaining)
            remaining_best = max(totals.values()) if totals else 0

            # suit counts in remaining hand
            suit_counts = {}
            for c in remaining:
                suit_counts[c.suit] = suit_counts.get(c.suit, 0) + 1
            # tiebreak score: prefer discarding from suits with count 1 and low points
            candidate_points = self._card_points(candidate)
            candidate_suit_count = suit_counts.get(candidate.suit, 0)
            tiebreak = ( -candidate_suit_count, -candidate_points )

            if remaining_best > best_remaining_score:
                best_remaining_score = remaining_best
                best_discard = candidate
                best_tiebreak = tiebreak
            elif remaining_best == best_remaining_score:
                if tiebreak > best_tiebreak:
                    best_discard = candidate
                    best_tiebreak = tiebreak

        # As a final safeguard, don't discard a card that would drop our best below a usable threshold
        if best_discard is None:
            return cards[0]
        return best_discard
