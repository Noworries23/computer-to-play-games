from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove
from ThirtyOne.ThirtyOneBoard import ThirtyOneBoard

class ThirtyOneDeThomasPlayer():
    def __init__(self):
        self.name = "DeThomas"
        self.turn = 0

    def card_value(self, card):
        if card.rank.name in ['JACK', 'QUEEN', 'KING']:
            return 10
        elif card.rank.name == 'ACE':
            return 11
        else:
            return int(card.rank.value)

    def suit_sums(self, cards):
        suits = {}
        for card in cards:
            suits.setdefault(card.suit, 0)
            suits[card.suit] += self.card_value(card)
        return suits

    def choose_draw_move(self, cards, top_discard, move_storage):
        self.turn += 1

        suits = self.suit_sums(cards)
        best_suit = max(suits, key=suits.get)
        best_value = suits[best_suit]

        knock_threshold = min(31, 15 + 2 * (self.turn - 1))

        # Knock condition
        if best_value >= knock_threshold or best_value >= 24:
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        # Draw from discard if it improves best suit
        if top_discard.suit == best_suit:
            if self.card_value(top_discard) > min(
                self.card_value(c) for c in cards if c.suit == best_suit
            ):
                return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        suits = self.suit_sums(cards)
        best_suit = max(suits, key=suits.get)

        # Prefer discarding cards NOT in best suit
        non_best = [c for c in cards if c.suit != best_suit]
        if non_best:
            return min(non_best, key=self.card_value)

        # Otherwise discard lowest card in best suit
        return min(cards, key=self.card_value)