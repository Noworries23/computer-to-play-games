from calendar import c
from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneVishnuEricHarishPlayer():
    def __init__(self):
        super().__init__()
        self.name = "Horosh, Eroc, and Voshno"

    def choose_draw_move(self, cards, top_discard, move_storage):
        # print(top_discard)

        if self.calculate_score(cards) >= 26:
            return ThirtyOneDrawChoiceMove.Choice.KNOCK


        if self.calculate_score(cards) < self.calculate_score(cards + [top_discard]) :
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
        else:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        # Example strategy: discard the first card in hand
        discardable = []
        for i in range(len(cards)):
            cards_to_check = cards.copy()
            cards_to_check.pop(i)
            # self.printDeck(cards_to_check)
            # self.printDeck(cards)
            if self.calculate_score(cards_to_check) == self.calculate_score(cards):
                discardable.append(cards[i])
        minRank = 20
        card_to_discard = cards[0]
        for card in discardable:
            if card.rank.value < minRank:
                minRank = card.rank.value
                card_to_discard = card
        if len(discardable) == 0:
            for card in cards:
                if card.rank.value < minRank:
                    minRank = card.rank.value
                    card_to_discard = card
        # print("Debating which card to discard among:")
        # for card in cards:
        #     print(card.suit, card.rank)
        #print("Chose to discard:")
        # print(card_to_discard.suit, card_to_discard.rank)
        return card_to_discard

    def calculate_score(self, cards):
        suit_totals = [0,0,0,0]
        for i in range(1,5):
            # print("Suit being analyzed:", i)
            for card in cards:
                # print("Card being anaylzed: ", card.suit.value, card.rank.value)
                if card.suit.value == i:
                    if card.rank.value >= 10:
                        suit_totals[i-1] += 10
                        # print(suit_totals)
                    elif card.rank.value == 1:
                        suit_totals[i-1] += 11
                        # print(suit_totals)
                    else:
                        suit_totals[i-1] += card.rank.value
                        # print(suit_totals)
        return max(suit_totals)

    def printDeck(self, cards):
        for card in cards:
            print(card.suit, card.rank)

