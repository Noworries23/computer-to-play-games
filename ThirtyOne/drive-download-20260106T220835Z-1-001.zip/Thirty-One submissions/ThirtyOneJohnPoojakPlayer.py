from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove
from ThirtyOne.Card import Card
from typing import List, Optional, Dict
import random


class ThirtyOneYOURNAMEPlayer:
    def __init__(self):
        super().__init__()
        self.name = "POOJAK and JOHN"

    # ---------- basic helpers ----------

    def _card_value(self, card: Card) -> int:
        if card.rank.name in ["JACK", "QUEEN", "KING"]:
            return 10
        if card.rank.name == "ACE":
            return 11
        return int(card.rank.value)

    def _best_suit_value(self, cards: List[Card]) -> int:
        totals: Dict[Card.Suit, int] = {}
        for c in cards:
            totals[c.suit] = totals.get(c.suit, 0) + self._card_value(c)
        return max(totals.values()) if totals else 0

    def _target_suit(self, cards: List[Card]) -> Card.Suit:
        totals: Dict[Card.Suit, int] = {}
        counts: Dict[Card.Suit, int] = {}
        for c in cards:
            v = self._card_value(c)
            totals[c.suit] = totals.get(c.suit, 0) + v
            counts[c.suit] = counts.get(c.suit, 0) + 1
        if not totals:
            return Card.Suit.CLUBS
        best_val = max(totals.values())
        cands = [s for s, v in totals.items() if v == best_val]
        if len(cands) == 1:
            return cands[0]
        # tie-break by how many cards we already have in that suit
        cands.sort(key=lambda s: counts.get(s, 0), reverse=True)
        return cands[0]

    # ---------- Monte Carlo evaluation ----------

    def _simulate_expected_value(
        self,
        cards: List[Card],
        draws_remaining: int,
        trials: int = 250,
    ) -> float:
        """
        Monte Carlo: take this starting hand, simulate random future draws
        and optimal discards, and return average best suit value.
        """
        if draws_remaining <= 0:
            return float(self._best_suit_value(cards))

        base_vals = [self._card_value(c) for c in cards]
        suits = [c.suit for c in cards]

        results: List[float] = []

        for _ in range(trials):
            # work on copies so we don't mutate originals
            hand_vals = list(base_vals)
            hand_suits = list(suits)

            # simulate draws_remaining future unknown cards
            for _ in range(draws_remaining):
                # random “realistic” value and suit
                v = random.choices(
                    population=[4, 5, 6, 7, 8, 9, 10, 11],
                    weights=[1, 2, 3, 4, 4, 3, 3, 1],
                    k=1,
                )[0]
                s = random.choice([
                    Card.Suit.CLUBS,
                    Card.Suit.DIAMONDS,
                    Card.Suit.HEARTS,
                    Card.Suit.SPADES,
                ])
                hand_vals.append(v)
                hand_suits.append(s)

                # discard the card whose removal keeps best suited sum max
                best_after = -1
                best_idx = 0
                for i in range(len(hand_vals)):
                    tmp_vals = hand_vals[:i] + hand_vals[i+1:]
                    tmp_suits = hand_suits[:i] + hand_suits[i+1:]
                    totals: Dict[Card.Suit, int] = {}
                    for val, suit in zip(tmp_vals, tmp_suits):
                        totals[suit] = totals.get(suit, 0) + val
                    if totals:
                        cand = max(totals.values())
                    else:
                        cand = 0
                    if cand > best_after:
                        best_after = cand
                        best_idx = i
                # actually discard that card
                hand_vals.pop(best_idx)
                hand_suits.pop(best_idx)

            # final best-suit value for this trial
            totals: Dict[Card.Suit, int] = {}
            for val, suit in zip(hand_vals, hand_suits):
                totals[suit] = totals.get(suit, 0) + val
            results.append(max(totals.values()) if totals else 0)

        return sum(results) / len(results) if results else 0.0

    # ---------- draw logic ----------

    def choose_draw_move(
        self,
        cards: List[Card],
        top_discard: Optional[Card],
        move_storage: List[str],
    ):
        if top_discard == 0:
            top_discard = None

        current_value = self._best_suit_value(cards)

        # Be greedy about knocking: only with very strong hands
        # 29+ basically crushes average opposition, 30/31 almost auto-win.
        if current_value >= 29 and not any("knocked" in s.lower() for s in move_storage):
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        # If no discard available, must draw from deck
        if top_discard is None:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

        # Estimate how many draws are likely left before round ends.
        # More moves in history -> later game -> fewer draws remaining.
        turns_so_far = max(1, len(move_storage))
        if turns_so_far < 12:
            draws_left = 3
        elif turns_so_far < 20:
            draws_left = 2
        else:
            draws_left = 1

        # Option A: take top_discard
        hand_take = list(cards) + [top_discard]
        exp_take = self._simulate_expected_value(hand_take, draws_left)

        # Option B: draw from deck (unknown card)
        # Approximate the unknown card with value and random suit, then simulate.
        fake_val = random.choices(
            population=[4, 5, 6, 7, 8, 9, 10, 11],
            weights=[1, 2, 3, 4, 4, 3, 3, 1],
            k=1,
        )[0]
        fake_suit = random.choice([
            Card.Suit.CLUBS,
            Card.Suit.DIAMONDS,
            Card.Suit.HEARTS,
            Card.Suit.SPADES,
        ])

        # Build a fake card-like structure by cloning first card’s type
        class _FakeCard:
            def __init__(self, v, s):
                self._v = v
                self.suit = s
                class Rank:
                    def __init__(self, v):
                        self.value = v
                        self.name = (
                            "ACE" if v == 11
                            else "KING" if v == 10
                            else "TEN" if v == 10
                            else str(v)
                        )
                self.rank = Rank(v)

        fake_card = _FakeCard(fake_val, fake_suit)
        hand_deck = list(cards) + [fake_card]  # type: ignore[arg-type]
        exp_deck = self._simulate_expected_value(hand_deck, draws_left)

        # If taking discard gives a clearly higher expected value, do it.
        # Otherwise take from deck for variance.
        if exp_take >= exp_deck + 0.5:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD
        else:
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    # ---------- discard logic ----------

    def choose_discard_move(
        self,
        cards: List[Card],
        top_discard: Optional[Card],
        move_storage: List[str],
    ) -> Card:
        if top_discard == 0:
            top_discard = None

        # Prefer to build towards a target suit.
        target = self._target_suit(cards)

        best_score = -1.0
        best_discards: List[Card] = []

        # Assume 1–2 draws left when choosing discard; this makes discards more “future aware”.
        draws_left = 2

        for c in cards:
            kept = [x for x in cards if x is not c]
            # base value of this keep set
            base_val = self._best_suit_value(kept)
            # Monte Carlo expected improvement if we keep this set
            exp_val = self._simulate_expected_value(kept, draws_left, trials=80)
            # bonus for reinforcing target suit
            suit_bonus = 0.0
            for k in kept:
                if k.suit == target:
                    suit_bonus += 0.3

            score = exp_val + 0.2 * base_val + suit_bonus

            if score > best_score:
                best_score = score
                best_discards = [c]
            elif score == best_score:
                best_discards.append(c)

        # If tie, discard the lowest-value card among the candidates
        return min(best_discards, key=lambda c: self._card_value(c))
