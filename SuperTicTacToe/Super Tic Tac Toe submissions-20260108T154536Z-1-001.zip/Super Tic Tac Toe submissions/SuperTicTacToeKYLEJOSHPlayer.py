from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random

MINIMAX_DEPTH = 4 # Do not change this

class SuperTicTacToeKYLEJOSHPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("George Washingmachine", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        try:
            # Read the master board
            master_winner = board.master_board.winner

            # Check if game is over
            if master_winner is not None:
                if master_winner == player:
                    return 1.0  # We won
                else:
                    return -1.0  # We lost

            # Get opponent
            opponent = board.players[0] if board.players[1] == player else board.players[1]

            # Simple heuristic: count advantages
            score = 0.0

            # 1. Count sub-boards we've won (worth a lot!)
            for row in range(3):
                for col in range(3):
                    sub_winner = board.sub_boards[row][col].winner
                    if sub_winner == player:
                        score += 0.3  # We won this sub-board
                    elif sub_winner is not None:
                        score -= 0.3  # Opponent won this sub-board

            # 2. Count our marks in unsettled sub-boards (worth a little)
            for row in range(3):
                for col in range(3):
                    sub_board = board.sub_boards[row][col]
                    # Only count if this sub-board is still playable
                    if sub_board.winner is None and not sub_board.is_full:

                        # Center
                        if sub_board.board[1][1] == player:
                            score += 0.01

                        # Corners
                        for cell_row in range(2):
                            for cell_col in range(2):
                                cell = sub_board.board[cell_row*2][cell_col*2]
                                if cell == player:
                                    score += 0.01

                        # Check this sub-board for two-in-a-row
                        two_in_row_count = self.count_two_in_row(sub_board.board, player)
                        score += two_in_row_count * 0.05

                        # Opponent's two-in-a-row (defensive - we should block!)
                        opp_two_in_row = self.count_two_in_row(sub_board.board, opponent)
                        score -= opp_two_in_row * 0.06  # Slightly more weight to defense

                        for cell_row in range(3):
                            for cell_col in range(3):
                                cell_value = sub_board.board[cell_row][cell_col]
                                if cell_value == player:
                                    score += 0.01  # Our mark
                                elif cell_value is not None:
                                    score -= 0.01  # Opponent's mark

            # 3. Penalty if opponent will be sent to a dangerous board
            if board.current_board is not None:
                next_board_row, next_board_col = board.get_indices(board.current_board)
                if next_board_row is not None:
                    next_board = board.sub_boards[next_board_row][next_board_col]
                    if next_board.winner is None and not next_board.is_full:
                        # Check if opponent has threats in the board they'll play on
                        opp_threats = self.count_two_in_row(next_board.board, opponent)
                        score -= opp_threats * 0.05  # Penalty for sending them somewhere dangerous

            # Normalize to [-1, 1] range
            # Max realistic score estimation:
            # - Sub-boards won: 9 * 0.3 = 2.7
            # - Two-in-a-row: ~4 per board * 9 boards * 0.06 = 2.16
            # - Centers + corners: ~5 * 9 * 0.01 = 0.45
            # - Regular marks: 81 * 0.01 = 0.81
            # Total: ~6.12, use 6.0 for normalization
            score = max(-1.0, min(1.0, score / 6.0))

            return score

        except Exception as e:
            print(f"ERROR in scoreBoard: {e}")
            print(f"Error type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            return 0.0  # Return neutral score on error

    def count_two_in_row(self, board_3x3, player):
        """Count how many two-in-a-row opportunities exist for the player"""
        count = 0

        # Check all rows
        for row in range(3):
            player_count = sum(1 for col in range(3) if board_3x3[row][col] == player)
            empty_count = sum(1 for col in range(3) if board_3x3[row][col] is None)
            if player_count == 2 and empty_count == 1:
                count += 1

        # Check all columns
        for col in range(3):
            player_count = sum(1 for row in range(3) if board_3x3[row][col] == player)
            empty_count = sum(1 for row in range(3) if board_3x3[row][col] is None)
            if player_count == 2 and empty_count == 1:
                count += 1

        # Check diagonal (top-left to bottom-right)
        player_count = sum(1 for i in range(3) if board_3x3[i][i] == player)
        empty_count = sum(1 for i in range(3) if board_3x3[i][i] is None)
        if player_count == 2 and empty_count == 1:
            count += 1

        # Check anti-diagonal (top-right to bottom-left)
        player_count = sum(1 for i in range(3) if board_3x3[i][2-i] == player)
        empty_count = sum(1 for i in range(3) if board_3x3[i][2-i] is None)
        if player_count == 2 and empty_count == 1:
            count += 1

        return count

