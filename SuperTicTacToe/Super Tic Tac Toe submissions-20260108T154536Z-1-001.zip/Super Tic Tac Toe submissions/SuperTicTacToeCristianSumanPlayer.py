from MinimaxPlayer import MinimaxPlayer
import math

MINIMAX_DEPTH = 4  # Do not change this


class SuperTicTacToeCristianSumanPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("Cristian + Suman", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        """Evaluate `board` for `player`.

        Uses the actual `sub_boards` structure where each sub-board's
        cells contain Player instances or None and each sub-board has
        a `winner` attribute (Player or None).
        """

        # find opponent Player instance
        opponent = next((p for p in board.players if p is not player), None)
        if opponent is None:
            return 0.0

        # Helper: map a sub-board (SingleTicTacToeBoard) to numeric 3x3 grid
        def small_board_nums(br, bc):
            sb = board.sub_boards[br][bc].board
            def to_num(cell):
                if cell is None:
                    return 0
                return 1 if cell is player else 2
            return [[to_num(sb[r][c]) for c in range(3)] for r in range(3)]

        LINES = [
            [(r, 0), (r, 1), (r, 2)] for r in range(3)
        ] + [
            [(0, c), (1, c), (2, c)] for c in range(3)
        ] + [
            [(0, 0), (1, 1), (2, 2)],
            [(0, 2), (1, 1), (2, 0)],
        ]

        def line_value(grid, p):
            score = 0
            for line in LINES:
                marks = [grid[r][c] for r, c in line]
                if marks.count(p) == 2 and marks.count(0) == 1:
                    score += 3
                elif marks.count(p) == 1 and marks.count(0) == 2:
                    score += 1
            return score

        # Build big meta-grid: 1 = me, 2 = opponent, 0 = none
        meta = [[0] * 3 for _ in range(3)]
        for r in range(3):
            for c in range(3):
                winner = board.sub_boards[r][c].winner
                if winner is None:
                    meta[r][c] = 0
                else:
                    meta[r][c] = 1 if winner is player else 2

        big_value = line_value(meta, 1) - line_value(meta, 2)

        # Evaluate local boards
        local_value = 0
        for r in range(3):
            for c in range(3):
                if meta[r][c] != 0:
                    continue
                small = small_board_nums(r, c)
                local_value += line_value(small, 1)
                local_value -= line_value(small, 2)

        # small heuristics for center/corners on each small board
        pos_value = 0
        for r in range(3):
            for c in range(3):
                if meta[r][c] != 0:
                    continue
                sb = small_board_nums(r, c)
                if sb[1][1] == 1:
                    pos_value += 0.4
                if sb[1][1] == 2:
                    pos_value -= 0.4
                corners = [(0, 0), (0, 2), (2, 0), (2, 2)]
                pos_value += 0.2 * sum(1 for (rr, cc) in corners if sb[rr][cc] == 1)
                pos_value -= 0.2 * sum(1 for (rr, cc) in corners if sb[rr][cc] == 2)

        # Combine
        score = 4 * big_value + local_value + pos_value
        return math.tanh(score / 20.0)
        
