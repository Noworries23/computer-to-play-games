from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove

MINIMAX_DEPTH = 4  # Do not change


class SuperTicTacToe_Anthony_Macintosh_Player(MinimaxPlayer):
    def __init__(self, name="Anthony Macintosh"):
        super().__init__(name, MINIMAX_DEPTH)

    def _opponent(self, board, player):
        return board.players[0] if board.players[1] == player else board.players[1]

    def getMove(self, board):
        """Return a valid SuperTicTacToeMove for the current board.

        Strategy (simple, robust):
        1) If any immediate local winning move exists for self, play it.
        2) Else if any local two-in-a-row threat exists for opponent, block it.
        3) Else prefer center of the active small board if available.
        4) Else return the first available move.
        """
        player = self
        opponent = self._opponent(board, player)

        possible = board.getPossibleMoves()
        if not possible:
            return None

        # 1) immediate local win for self
        win_move = self._find_two_in_a_row_move(board, player, player)
        if win_move:
            return win_move

        # 2) block opponent's local win
        block_move = self._find_two_in_a_row_move(board, player, opponent)
        if block_move:
            return block_move

        # 3) prefer center of active board (if present) but avoid overusing it
        center_count = self._count_position_across_subboards(board, player, (1, 1))
        if center_count < 2:
            for m in possible:
                if (m.positionx, m.positiony) == (1, 1):
                    return m
        # if center is overused, prefer corners that are not overused
        corners = [(0, 0), (0, 2), (2, 0), (2, 2)]
        for corner in corners:
            cnt_corner = self._count_position_across_subboards(board, player, corner)
            if cnt_corner < 2:
                for m in possible:
                    if (m.positionx, m.positiony) == corner:
                        return m

        # 4) fallback: deterministic first move (sorted to be stable)
        possible.sort(key=lambda mv: (mv.boardx, mv.boardy, mv.positionx, mv.positiony))
        return possible[0]

    def _find_two_in_a_row_move(self, board, player_to_play, target_player):
        """Scan allowed small boards for any line where `target_player` has two marks
        and the third cell is empty. If found, return the matching possible move
        (so the returned move has the correct player field set)."""
        possible = board.getPossibleMoves()

        # Allowed small boards: either current_board or all
        allowed_boards = []
        if board.current_board is None:
            allowed_boards = [(r, c) for r in range(3) for c in range(3)]
        else:
            # find indices for current_board
            try:
                cb_r, cb_c = board.get_indices(board.current_board)
                allowed_boards = [(cb_r, cb_c)]
            except Exception:
                # fallback: allow all
                allowed_boards = [(r, c) for r in range(3) for c in range(3)]

        for br, bc in allowed_boards:
            sb = board.sub_boards[br][bc]
            if sb.winner is not None or sb.is_full:
                continue
            grid = sb.board
            for line in self._lines_coords():
                cells = [grid[r][c] for (r, c) in line]
                target_count = sum(1 for x in cells if x == target_player)
                empty_positions = [(r, c) for (r, c), x in zip(line, cells) if x is None]
                if target_count == 2 and len(empty_positions) == 1:
                    er, ec = empty_positions[0]
                    # find the corresponding possible move (ensures correct player field)
                    for m in possible:
                        if m.boardx == br and m.boardy == bc and m.positionx == er and m.positiony == ec:
                            return m
        return None

    def _lines_coords(self):
        # return list of 3-cell coordinate triples for a 3x3 board
        lines = []
        for i in range(3):
            lines.append([(i, 0), (i, 1), (i, 2)])
            lines.append([(0, i), (1, i), (2, i)])
        lines.append([(0, 0), (1, 1), (2, 2)])
        lines.append([(0, 2), (1, 1), (2, 0)])
        return lines

    def scoreBoard(self, board, player):
        # Minimal heuristic: prefer owning small boards and center control
        opponent = self._opponent(board, player)
        score = 0
        for r in range(3):
            for c in range(3):
                sb = board.sub_boards[r][c]
                if sb.winner == player:
                    score += 10
                elif sb.winner == opponent:
                    score -= 10
                else:
                    # positional bonus
                    if sb.board[1][1] == player:
                        score += 1
        return score

    def _count_position_across_subboards(self, board, player, pos):
        """Count how many times `player` occupies `pos` across all subboards."""
        rpos, cpos = pos
        cnt = 0
        for r in range(3):
            for c in range(3):
                sb = board.sub_boards[r][c]
                if sb.board[rpos][cpos] == player:
                    cnt += 1
        return cnt

  
