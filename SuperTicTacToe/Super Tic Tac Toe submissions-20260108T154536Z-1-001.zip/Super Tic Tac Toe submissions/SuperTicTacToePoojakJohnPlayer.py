import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from MinimaxPlayer import MinimaxPlayer
from TiePlayer import TiePlayer

from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
from SuperTicTacToe.SingleTicTacToeBoard import SingleTicTacToeBoard
from SuperTicTacToe.SuperTicTacToeBoard import SuperTicTacToeBoard
from Player import Player
import random


# ============================================================
# PATCH: Detect tie / no-legal-move states so game can finish
# ============================================================
if not hasattr(SuperTicTacToeBoard, "_tie_patch_applied"):
    _orig_getGameEnded = SuperTicTacToeBoard.getGameEnded

    def _patched_getGameEnded(self):
        winner = _orig_getGameEnded(self)
        if winner:
            return winner

        # No possible moves = tie
        try:
            if len(self.getPossibleMoves()) == 0:
                return TiePlayer(self.players)
        except Exception:
            pass

        return False

    SuperTicTacToeBoard.getGameEnded = _patched_getGameEnded
    SuperTicTacToeBoard._tie_patch_applied = True


def singleBoardScore(board: SingleTicTacToeBoard, player: Player) -> float:
    opp = None
    for r in range(3):
        for c in range(3):
            if board.board[r][c] is not None and board.board[r][c] != player:
                opp = board.board[r][c]
                break
        if opp is not None:
            break

    if opp is None:
        class _Dummy: pass
        opp = _Dummy()

    def line_score(cells):
        p = sum(1 for x in cells if x == player)
        o = sum(1 for x in cells if x == opp)

        if p > 0 and o > 0:
            return 0.0

        if p == 3:
            return 100000.0
        if o == 3:
            return -100000.0

        if p == 2:
            return 60.0
        if o == 2:
            return -75.0

        if p == 1:
            return 8.0
        if o == 1:
            return -9.0

        return 0.0

    score = 0.0

    for r in range(3):
        score += line_score(board.board[r])

    for c in range(3):
        score += line_score([board.board[0][c], board.board[1][c], board.board[2][c]])

    score += line_score([board.board[0][0], board.board[1][1], board.board[2][2]])
    score += line_score([board.board[0][2], board.board[1][1], board.board[2][0]])

    # positional bonus
    weights = [
        [3, 1, 3],
        [1, 5, 1],
        [3, 1, 3]
    ]

    for r in range(3):
        for c in range(3):
            if board.board[r][c] == player:
                score += weights[r][c]
            elif board.board[r][c] == opp:
                score -= weights[r][c]

    return score / 100.0


def opponentOf(board: SuperTicTacToeBoard, player: Player) -> Player:
    for p in board.players:
        if p != player:
            return p
    return player


MINIMAX_DEPTH = 4  # DO NOT CHANGE


class SuperTicTacToePoojakJohnPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("Poojak + John", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        opponent = opponentOf(board, player)

        local_score = 0.0
        counted = 0
        for i in range(3):
            for j in range(3):
                sb = board.sub_boards[i][j]
                if sb.winner is not None or sb.is_full:
                    continue
                local_score += singleBoardScore(sb, player) - singleBoardScore(sb, opponent)
                counted += 1

        if counted > 0:
            local_score /= counted

        macro_score = (
            singleBoardScore(board.master_board, player)
            - singleBoardScore(board.master_board, opponent)
        )

        current_score = 0.0
        if board.current_board and board.current_board.winner is None and not board.current_board.is_full:
            current_score = (
                singleBoardScore(board.current_board, player)
                - singleBoardScore(board.current_board, opponent)
            )

        return (0.55 * local_score) + (0.35 * macro_score) + (0.10 * current_score)
