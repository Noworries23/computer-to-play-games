from ThirtyOne.ThirtyOneMove import ThirtyOneDrawChoiceMove
from ThirtyOne.ThirtyOneMove import ThirtyOneDiscardMove

class ThirtyOneSammieSamPlayerv1():
    def __init__(self):
        super().__init__()
        self.name = "Sammie, Sam"

    def choose_draw_move(self, cards, top_discard, move_storage):
        # Score current cards using CardScorer
        current_scorer = CardScorer(cards)
        #print(f"[DEBUG] {self.name} - Current hand: {[str(c) for c in cards]}")
        #print(f"[DEBUG] {self.name} - Current scores: {current_scorer.suit_totals}, max: {current_scorer.get_max_score()}")

        # Score if we draw the top discard
        discard_scorer = CardScorer(cards + [top_discard])
        #print(f"[DEBUG] {self.name} - Top discard: {top_discard}")
        #print(f"[DEBUG] {self.name} - Discard scores: {discard_scorer.suit_totals}, max: {discard_scorer.get_max_score()}")

        # Check if score increases by taking the discard
        if current_scorer.get_max_score() < discard_scorer.get_max_score():
            #print(f"[DEBUG] {self.name} - Decision: DRAW_FROM_DISCARD (improves score)")
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DISCARD

        # If score exceeds threshold knock
        elif current_scorer.get_max_score() == 29:
            #print(f"[DEBUG] {self.name} - Decision: KNOCK (score is 29)")
            return ThirtyOneDrawChoiceMove.Choice.KNOCK

        # If score doesnt improve by taking drawn card draw from deck
        else:
            #print(f"[DEBUG] {self.name} - Decision: DRAW_FROM_DECK (no improvement)")
            return ThirtyOneDrawChoiceMove.Choice.DRAW_FROM_DECK

    def choose_discard_move(self, cards, top_discard, move_storage):
        # Use CardScorer to analyze the hand
        scorer = CardScorer(cards)
        best_suit = scorer.get_best_suit()
        #print(f"[DEBUG] {self.name} - Hand scores: {scorer.suit_totals}, best suit: {best_suit}")
        
        # Find the card to discard - prioritize cards not in best suit
        worst_card = None
        worst_value = float('inf')
        
        # First, try to find a card not in the best suit
        for card in cards:
            if card.suit.value != best_suit:
                card_value = scorer.value_dict[card.rank.value]
                if worst_card is None or card_value < worst_value:
                    worst_card = card
                    worst_value = card_value
        
        # If all cards are in the best suit, discard the lowest value card
        if worst_card is None:
            worst_card = min(cards, key=lambda c: scorer.value_dict[c.rank.value])
        
        #print(f"[DEBUG] {self.name} - Discarding: {worst_card}")
        #print(f"[DEBUG] {self.name} - Remaining cards: {[str(c) for c in cards if c != worst_card]}")
        return worst_card


# Define a card scorer that sorts cards based on suit and also totals scores but also tells you 
# what cards are in each suit individually
class CardScorer():
    # matches card index to the score it gives
    value_dict = {1: 11, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10, 
                11: 10, 12: 10, 13: 10}
    
    def __init__(self, cards):
        super().__init__()
        self.cards = cards
        self.suits_dict = self._organize_by_suit()
        self.suit_totals = self._calculate_totals()
    
    def _organize_by_suit(self):
        """Organize cards by suit"""
        suits = {1: [], 2: [], 3: [], 4: []}
        for card in self.cards:
            suits[card.suit.value].append(card)
        # Sort cards within each suit by value (descending)
        for suit in suits:
            suits[suit].sort(key=lambda c: self.value_dict[c.rank.value], reverse=True)
        return suits
    
    def _calculate_totals(self):
        """Calculate total score for each suit"""
        totals = {1: 0, 2: 0, 3: 0, 4: 0}
        for suit, cards in self.suits_dict.items():
            totals[suit] = sum(self.value_dict[card.rank.value] for card in cards)
        return totals
    
    def get_cards_in_suit(self, suit):
        """Get all cards in a specific suit"""
        return self.suits_dict[suit]
    
    def get_best_suit(self):
        """Get the suit with the highest total score"""
        return max(self.suit_totals, key=self.suit_totals.get)
    
    def get_worst_suit(self):
        """Get the suit with the lowest total score"""
        return min(self.suit_totals, key=self.suit_totals.get)
    
    def get_max_score(self):
        """Get the maximum score across all suits"""
        return max(self.suit_totals.values())
