from MinimaxPlayer import MinimaxPlayer

MINIMAX_DEPTH = 4  # keep depth local to this file


class SuperTicTacToeJeremyPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("Jeremy", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        opponent = [p for p in board.players if p != player][0]
        score = 0

        # 0. Quick terminal check – absolute priority
        if board.master_board.winner == player:
            return 100000
        if board.master_board.winner == opponent:
            return -100000

        # Estimate game phase: 1.0 = opening, 0.0 = very late
        total_small = 9
        decided_small = 0
        for r in range(3):
            for c in range(3):
                sb = board.sub_boards[r][c]
                if sb.winner is not None or sb.is_full:
                    decided_small += 1
        game_phase = max(0.0, min(1.0, 1.0 - decided_small / total_small))

        # 1. Sub-board wins + local structure
        my_small_wins = 0
        opp_small_wins = 0

        for r in range(3):
            for c in range(3):
                sb = board.sub_boards[r][c]
                if sb.winner == player:
                    score += 350
                    my_small_wins += 1
                elif sb.winner == opponent:
                    score -= 350
                    opp_small_wins += 1
                else:
                    my_threats = self.immediate_threats(sb, player)
                    opp_threats = self.immediate_threats(sb, opponent)

                    # Strong tactical emphasis: take wins, block wins
                    score += my_threats * 45
                    score -= opp_threats * 50

                    # Softer positional value
                    score += self.evaluate_subboard(sb, player) * 3
                    score -= self.evaluate_subboard(sb, opponent) * 3

        # 2. Master-board threats – very important
        my_master_threats = self.immediate_threats(board.master_board, player)
        opp_master_threats = self.immediate_threats(board.master_board, opponent)

        score += my_master_threats * 220
        score -= opp_master_threats * 240

        score += self.evaluate_subboard(board.master_board, player) * 25
        score -= self.evaluate_subboard(board.master_board, opponent) * 25

        # 3. Mobility – small stabilizer
        my_moves = len(board.getPossibleMoves())
        original_current = board.current_player
        board.current_player = opponent
        opp_moves = len(board.getPossibleMoves())
        board.current_player = original_current
        score += (my_moves - opp_moves) * 0.1

        # 4. Forced-board logic – scaled by game phase
        score += self.forced_board_value(
            board, player, opponent, my_small_wins, opp_small_wins, game_phase
        )

        return score

    def immediate_threats(self, sb, player):
        """
        Counts lines where player has 2 and one empty (i.e., can win next move).
        """
        b = sb.board
        count = 0

        # Rows
        for r in range(3):
            row = b[r]
            if row.count(player) == 2 and row.count(None) == 1:
                count += 1

        # Columns
        for c in range(3):
            col = [b[0][c], b[1][c], b[2][c]]
            if col.count(player) == 2 and col.count(None) == 1:
                count += 1

        # Diagonals
        diag1 = [b[0][0], b[1][1], b[2][2]]
        diag2 = [b[0][2], b[1][1], b[2][0]]

        for diag in (diag1, diag2):
            if diag.count(player) == 2 and diag.count(None) == 1:
                count += 1

        return count

    def evaluate_subboard(self, sb, player):
        """
        Softer positional evaluation: one-in-a-row, center, etc.
        Immediate threats are handled separately.
        """
        b = sb.board
        val = 0

        # Rows
        for r in range(3):
            row = b[r]
            if row.count(player) == 1 and row.count(None) == 2:
                val += 0.5

        # Columns
        for c in range(3):
            col = [b[0][c], b[1][c], b[2][c]]
            if col.count(player) == 1 and col.count(None) == 2:
                val += 0.5

        # Diagonals
        diag1 = [b[0][0], b[1][1], b[2][2]]
        diag2 = [b[0][2], b[1][1], b[2][0]]

        for diag in (diag1, diag2):
            if diag.count(player) == 1 and diag.count(None) == 2:
                val += 0.5

        # Center preference
        if b[1][1] == player:
            val += 1.0

        return val

    def forced_board_value(self, board, player, opponent, my_small_wins, opp_small_wins, game_phase):
        """
        Evaluates the forced board situation with game-phase awareness:
        - Early game: more cautious about giving structural advantages.
        - Late game: more willing to trade structure for concrete wins / threats.
        """

        # Scale for how much we care about structure: high early, low late
        structure_weight = 0.6 + 0.4 * game_phase  # between 0.6 and 1.0
        late_game_factor = 1.0 - game_phase        # 0.0 early, 1.0 late

        # Case 1: opponent can move anywhere (current_board is None)
        if board.current_board is None:
            worst = 0
            instant_loss = False

            for r in range(3):
                for c in range(3):
                    sb = board.sub_boards[r][c]
                    if sb.winner is None and not sb.is_full:
                        opp_threat = self.immediate_threats(sb, opponent)
                        my_threat = self.immediate_threats(sb, player)

                        if opp_threat > 0:
                            instant_loss = True

                        val = opp_threat * 15 - my_threat * 8
                        if val > worst:
                            worst = val

            # If they have instant wins available everywhere and we're not clearly ahead,
            # be cautious early, but less so late.
            if instant_loss and my_small_wins <= opp_small_wins:
                return -250 * structure_weight

            return -worst * structure_weight

        # Case 2: opponent is forced into a specific board
        r, c = board.get_indices(board.current_board)
        forced = board.sub_boards[r][c]

        if forced.is_full:
            # Full → effectively same as free choice
            worst = 0
            instant_loss = False

            for i in range(3):
                for j in range(3):
                    sb = board.sub_boards[i][j]
                    if sb.winner is None and not sb.is_full:
                        opp_threat = self.immediate_threats(sb, opponent)
                        my_threat = self.immediate_threats(sb, player)

                        if opp_threat > 0:
                            instant_loss = True

                        val = opp_threat * 15 - my_threat * 8
                        if val > worst:
                            worst = val

            if instant_loss and my_small_wins <= opp_small_wins:
                return -250 * structure_weight

            return -worst * structure_weight

        # Case 3: forced into a non-full board → evaluate it
        opp_threats = self.immediate_threats(forced, opponent)
        my_threats = self.immediate_threats(forced, player)

        # If opponent has an immediate win and we have no counter-threat here,
        # it's bad early, but in late game we might still accept it if we're ahead.
        if opp_threats > 0 and my_threats == 0:
            # If we're behind or equal on small boards, be cautious.
            if my_small_wins <= opp_small_wins:
                return -280 * structure_weight
            else:
                # If we're ahead and late in the game, this penalty softens.
                return -200 * structure_weight * (1.0 - 0.5 * late_game_factor)

        # Otherwise, treat it as a contested battleground
        return (my_threats * 12 - opp_threats * 12) * structure_weight
