from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random

MINIMAX_DEPTH = 4 # Do not change this

class SuperTicTacToeHarishEricVishnuPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("HarishEricVishnu", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        # Assume player is a Player object; get opponent from board or by comparing to board.players
        # This assumes board has a list/tuple of players as board.players
        if hasattr(board, 'players'):
            opponent = next(p for p in board.players if p is not player)
        else:
            # Fallback: create a dummy opponent with a different name
            class Dummy: pass
            opponent = Dummy()
            opponent.name = 'opponent'

        score = 0
        for col in board.sub_boards:
            for b in col:
                # print("Evaluating sub-board:")
                # if player owns the center tile, add .25 points. if opponent, then -.25
                if b.board[1][1] == opponent:
                    score -= 0.25
                elif b.board[1][1] == player:
                    score += 0.25

                # Check the four corners of sub-board b for forks
                corners = [(0, 0), (0, 2), (2, 0), (2, 2)]
                player_corners = 0
                opponent_corners = 0
                for x, y in corners:
                    if b.board[x][y] == player:
                        player_corners += 1
                    elif b.board[x][y] == opponent:
                        opponent_corners += 1
                if player_corners == 3:
                    score += 1
                elif player_corners == 2:
                    score += 0.5
                if opponent_corners == 3:
                    score -= 1
                elif opponent_corners == 2:
                    score -= 0.5

                # if there are two in a row for player and the third is empty, add .75 points. if opponent, then -.75
                # if there are three in a row for player, add 1 point. if opponent, then -1 point
                for row in range(3):
                    for col_idx in range(3):
                        if b.board[row][col_idx] is None:
                            # Check row
                            if all(b.board[row][c] == player for c in range(3) if c != col_idx):
                                score += 0.75
                            elif all(b.board[row][c] == opponent for c in range(3) if c != col_idx):
                                score -= 0.75
                            # Check column
                            if all(b.board[r][col_idx] == player for r in range(3) if r != row):
                                score += 0.75
                            elif all(b.board[r][col_idx] == opponent for r in range(3) if r != row):
                                score -= 0.75
                            # Check diagonals
                            if row == col_idx:
                                if all(b.board[i][i] == player for i in range(3) if i != row):
                                    score += 0.75
                                elif all(b.board[i][i] == opponent for i in range(3) if i != row):
                                    score -= 0.75
                            if row + col_idx == 2:
                                if all(b.board[i][2 - i] == player for i in range(3) if i != row):
                                    score += 0.75
                                elif all(b.board[i][2 - i] == opponent for i in range(3) if i != row):
                                    score -= 0.75

                # Three in a row for player/opponent (row, col, diag) using same logic as two-in-a-row
                for i in range(3):
                    # Row
                    if all(b.board[i][c] == player for c in range(3)):
                        score += 1
                    elif all(b.board[i][c] == opponent for c in range(3)):
                        score -= 1
                    # Column
                    if all(b.board[r][i] == player for r in range(3)):
                        score += 1
                    elif all(b.board[r][i] == opponent for r in range(3)):
                        score -= 1
                # Main diagonal
                if all(b.board[d][d] == player for d in range(3)):
                    score += 1
                elif all(b.board[d][d] == opponent for d in range(3)):
                    score -= 1
                # Anti-diagonal
                if all(b.board[d][2-d] == player for d in range(3)):
                    score += 1
                elif all(b.board[d][2-d] == opponent for d in range(3)):
                    score -= 1


        if score != 0:
            print("new score:", score)
        return score
