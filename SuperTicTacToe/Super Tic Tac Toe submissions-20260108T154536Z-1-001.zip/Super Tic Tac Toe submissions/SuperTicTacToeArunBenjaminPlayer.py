from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random

MINIMAX_DEPTH = 4  # Do not change this

class SuperTicTacToeArunBenjaminPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("Arun Benjamin", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        opp = board.players[0] if board.players[1] == player else board.players[1]

        # eval
        winner = board.getGameEnded()
        if winner == player: return 10**9
        if winner == opp:    return -10**9

        # all possible win lines
        lines = [
            [(0,0),(0,1),(0,2)], [(1,0),(1,1),(1,2)], [(2,0),(2,1),(2,2)],
            [(0,0),(1,0),(2,0)], [(0,1),(1,1),(2,1)], [(0,2),(1,2),(2,2)],
            [(0,0),(1,1),(2,2)], [(0,2),(1,1),(2,0)]
        ]

        # eval a single sub-board
        def cell_score(sub):
            if sub.winner == player: return 80
            if sub.winner == opp:    return -80
            if sub.is_full:          return 0

            g = sub.board
            s = 0
            for L in lines:
                p = o = e = 0
                for r,c in L:
                    v = g[r][c]
                    if v == player: p += 1
                    elif v == opp:  o += 1
                    else:           e += 1
                if o == 0:
                    if p == 2 and e == 1: s += 14
                    elif p == 1 and e == 2: s += 4
                if p == 0:
                    if o == 2 and e == 1: s -= 16
                    elif o == 1 and e == 2: s -= 5

            if g[1][1] == player: s += 2
            elif g[1][1] == opp:  s -= 2
            return s

        # eval master board win potential
        def master_line_score(getw):
            s = 0
            for L in lines:
                p = o = e = 0
                for r,c in L:
                    w = getw(r,c)
                    if w == player: p += 1
                    elif w == opp:  o += 1
                    else:           e += 1
                if o == 0:
                    if p == 2 and e == 1: s += 260
                    elif p == 1 and e == 2: s += 80
                if p == 0:
                    if o == 2 and e == 1: s -= 280
                    elif o == 1 and e == 2: s -= 90
            return s

        # accumulate sub board values
        total = 0
        sub_val = [[0]*3 for _ in range(3)]
        for r in range(3):
            for c in range(3):
                v = cell_score(board.sub_boards[r][c])
                sub_val[r][c] = v
                total += v

        # add master board pressure
        total += master_line_score(lambda r,c: board.sub_boards[r][c].winner)
        total += (30 if board.sub_boards[1][1].winner == player else -30 if board.sub_boards[1][1].winner == opp else 0)

        # reward forcing opponent into bad sub boards
        if board.current_board is not None:
            br, bc = board.get_indices(board.current_board)
            forced = sub_val[br][bc]
            total += forced if board.current_player == player else -forced

        # lil noise to avoid symmetry
        total += random.uniform(-0.2, 0.2)
        return total
