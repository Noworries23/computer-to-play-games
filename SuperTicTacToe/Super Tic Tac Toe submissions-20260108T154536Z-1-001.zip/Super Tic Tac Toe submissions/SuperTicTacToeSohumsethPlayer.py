from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random

MINIMAX_DEPTH = 4 # Do not change this

class SuperTicTacToeSohumsethPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("Sohumseth", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        winner = board.getGameEnded()
        if winner:
            return 1.0 if winner == player else -1.0

        opponent = [p for p in board.players if p != player][0]
        score = 0.0

        weights = [
            [0.1, 0.05, 0.1],
            [0.05, 0.3, 0.05],
            [0.1, 0.05, 0.1]   
        ]

        M = board.master_board.board

        for r in range(3):
            for c in range(3):
                if M[r][c] == player:
                    score += weights[r][c]
                elif M[r][c] == opponent:
                    score -= weights[r][c]

        lines = [
            [(0,0),(0,1),(0,2)], [(1,0),(1,1),(1,2)], [(2,0),(2,1),(2,2)],
            [(0,0),(1,0),(2,0)], [(0,1),(1,1),(2,1)], [(0,2),(1,2),(2,2)],
            [(0,0),(1,1),(2,2)], [(0,2),(1,1),(2,0)]
        ]

        def is_empty(x):
            return x is None or x == " " or x == 0 or x == "."

        for line in lines:
            vals = [M[r][c] for (r,c) in line]
            if vals.count(player) == 2 and sum(is_empty(v) for v in vals) == 1:
                score += 0.6
            if vals.count(opponent) == 2 and sum(is_empty(v) for v in vals) == 1:
                score -= 0.65

        if board.current_board is not None:
            S = board.current_board.board
            for line in lines:
                vals = [S[r][c] for (r,c) in line]
                if vals.count(player) == 2 and sum(is_empty(v) for v in vals) == 1:
                    score += 0.15
                if vals.count(opponent) == 2 and sum(is_empty(v) for v in vals) == 1:
                    score -= 0.17

        return max(min(score, 0.99), -0.99)