from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
from SuperTicTacToe.SuperTicTacToeBoard import SuperTicTacToeBoard
from GameEngine import GameEngine
import random

MINIMAX_DEPTH = 4  # Do not change this


class SuperTicTacToeJacobAydenPlayer(MinimaxPlayer):
    def __init__(self, name="JacobAyden"):
        super().__init__(name, MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        winner = board.getGameEnded()
        if winner and winner in board.players:
            return 1 if winner == player else -1

        opponent = [p for p in board.players if p is not player][0]
        score = 0.0

        # Master board control
        master = board.master_board.board
        for r in range(3):
            for c in range(3):
                if master[r][c] is player:
                    score += 0.5
                elif master[r][c] is opponent:
                    score -= 0.5

        # Sub-board evaluation
        for sb_row in board.sub_boards:
            for sb in sb_row:
                if sb.winner == player:
                    score += 0.3
                elif sb.winner == opponent:
                    score -= 0.3
                else:
                    lines = []
                    lines.extend(sb.board)
                    lines.extend([[sb.board[r][c] for r in range(3)] for c in range(3)])
                    lines.append([sb.board[i][i] for i in range(3)])
                    lines.append([sb.board[i][2 - i] for i in range(3)])

                    for line in lines:
                        pcount = sum(1 for x in line if x is player)
                        ocount = sum(1 for x in line if x is opponent)

                        if ocount == 0 and pcount > 0:
                            score += 0.05 * pcount
                        elif pcount == 0 and ocount > 0:
                            score -= 0.05 * ocount

        return score


if __name__ == "__main__":
    # Existing bot
    p1 = MinimaxPlayer("Dong", MINIMAX_DEPTH)

    # My bot
    p2 = SuperTicTacToeJacobAydenPlayer("JacobAyden")

    board = SuperTicTacToeBoard(p1, p2)
    engine = GameEngine(board)

    # visualize=True lets you watch, no input needed
    winner = engine.run(visualize=True, pause=0)

    if winner:
        print("Winner:", winner.name)
    else:
        print("Tie game.")
