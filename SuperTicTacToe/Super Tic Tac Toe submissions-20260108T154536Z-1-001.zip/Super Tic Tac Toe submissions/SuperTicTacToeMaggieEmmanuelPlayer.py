from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random

MINIMAX_DEPTH = 4  # Do not change this

class SuperTicTacToeMaggieEmmanuelPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("MaggieEmmanuel", MINIMAX_DEPTH)

    # Probability-style heuristic for Ultimate Tic-Tac-Toe
    def scoreBoard(self, board, player):
        # Get opponent player object
        opponent = board.getOpponent(player)

        # Check terminal big board states
        if board.isWinner(player):
            return 1.0        # guaranteed win
        if board.isWinner(opponent):
            return -1.0       # guaranteed loss

        score = 0.0

        # Evaluate each small board
        for i in range(9):
            small = board.getSmallBoard(i)

            if small.isWinner(player):
                score += 0.1
            elif small.isWinner(opponent):
                score -= 0.1

        # Account for forced next-board rule
        if board.nextBoard is not None:
            forced = board.getSmallBoard(board.nextBoard)

            if not forced.isTerminal():  # only consider if board still playable
                if forced.isWinner(player):
                    score += 0.05
                elif forced.isWinner(opponent):
                    score -= 0.05

        # Clamp the score to [-1, 1]
        if score > 1.0:
            return 1.0
        if score < -1.0:
            return -1.0

        return score
