from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random

MINIMAX_DEPTH = 4 # Do not change this

class SuperTicTacToeAidanandRoyPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("Aidan and Roy", MINIMAX_DEPTH)

    def detectTwoAdjacent(self, board, player):
        # the board variable is always a singleboard
        count = 0
        b = board.board
        lines = []

        for r in range(3):
            lines.append(b[r])
        for c in range(3):
            lines.append([b[0][c], b[1][c], b[2][c]])

        # diagonals
        lines.append([b[0][0], b[1][1], b[2][2]])
        lines.append([b[0][2], b[1][1], b[2][0]])

        for line in lines:
            # the player is one move away from winning
            if (line[0] == player and line[1] == player and line[2] is None) or \
                (line[0] is None and line[1] == player and line[2] == player) or \
                (line[0] == player and line[1] is None and line[2] == player):
                count += 1
        return count

    def scoreBoard(self, board, player):
        # board: supertictactoeboard
        # player: the current player
 
        # weighting for each individual board, but also the larger board 
        # larger board: middle, +0.16 corners +0.15, edges +0.1 
        # for the larger: 2 adjacent with one open = +0.4
        # for the smaller: 2 adjacent with one open = +0.06
        # sending opp to a square where they can go anywhere = -0.05       

        heuristic = 0
        if board.players[0] == player:
            opponent = board.players[1]
        else:
            opponent = board.players[0]

        WIN_SUBBOARD = 0.1
        LARGE_BOARD_TWO_ADJ = 0.08
        SMALL_BOARD_TWO_ADJ = 0.012
        SEND_ANYWHERE_PENALTY = 0.01
        
        POS_WEIGHTS = [[0.03, 0.02, 0.03],
                       [0.02, 0.032, 0.02],
                       [0.03, 0.02, 0.03]]

        for r in range(3):
            for c in range(3):
                sub = board.sub_boards[r][c]
                pos_weight = POS_WEIGHTS[r][c]
                
                if sub.winner == player:
                    heuristic += WIN_SUBBOARD + pos_weight
                elif sub.winner == opponent:
                    heuristic -= WIN_SUBBOARD + pos_weight
                else:
                    # win hasnt happened yet
                    heuristic += SMALL_BOARD_TWO_ADJ * self.detectTwoAdjacent(sub, player)
                    heuristic -= SMALL_BOARD_TWO_ADJ * self.detectTwoAdjacent(sub, opponent)

        heuristic += LARGE_BOARD_TWO_ADJ * self.detectTwoAdjacent(board.master_board, player)
        heuristic -= LARGE_BOARD_TWO_ADJ * self.detectTwoAdjacent(board.master_board, opponent)

        # sending the opponent anywhere 
        if board.current_board is None:
            # opponents turn
            if board.currentPlayer() == opponent:
                heuristic -= SEND_ANYWHERE_PENALTY
            # our turn
            elif board.currentPlayer() == player:
                heuristic += SEND_ANYWHERE_PENALTY

        # print(f"current heuristic: {heuristic}")
        return heuristic

