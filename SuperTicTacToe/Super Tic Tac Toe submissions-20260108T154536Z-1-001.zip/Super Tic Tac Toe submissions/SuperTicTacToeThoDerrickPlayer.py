from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove

MINIMAX_DEPTH = 4  # Do not change this

class SuperTicTacToeThoDerrickPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("ThoDerrick", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        """
        Evaluates the board state for the given player.
        Returns a score where higher is better for the player.
        """
        opponent = 3 - player  # Assumes players are 1 and 2
        
        # Check if game is won
        winner = board.checkWinner()
        if winner == player:
            return 1000  # Win
        elif winner == opponent:
            return -1000  # Loss
        elif board.checkDraw():
            return 0  # Draw
        
        score = 0
  
        for bx in range(3):
            for by in range(3):
                small_board_score = self._evaluateSmallBoard(board, bx, by, player, opponent)
                score += small_board_score

        meta_score = self._evaluateMetaBoard(board, player, opponent)
        score += meta_score * 10 
        
        # Bonus for center control
        if board.bigBoard[1][1] == player:
            score += 5
        
        return score
    
    def _evaluateSmallBoard(self, board, bx, by, player, opponent):
        """Evaluates a single small 3x3 board."""
        small_board = board.board[bx][by]
        big_board_state = board.bigBoard[bx][by]
        
        # If this board is already won
        if big_board_state == player:
            return 30
        elif big_board_state == opponent:
            return -30
        elif big_board_state == 3:  # Draw
            return 0
        
        score = 0
        
        # Check rows, columns, and diagonals for potential wins
        lines = [
            # Rows
            [(0, 0), (0, 1), (0, 2)],
            [(1, 0), (1, 1), (1, 2)],
            [(2, 0), (2, 1), (2, 2)],
            # Columns
            [(0, 0), (1, 0), (2, 0)],
            [(0, 1), (1, 1), (2, 1)],
            [(0, 2), (1, 2), (2, 2)],
            # Diagonals
            [(0, 0), (1, 1), (2, 2)],
            [(0, 2), (1, 1), (2, 0)]
        ]
        
        for line in lines:
            player_count = sum(1 for px, py in line if small_board[px][py] == player)
            opponent_count = sum(1 for px, py in line if small_board[px][py] == opponent)
            empty_count = sum(1 for px, py in line if small_board[px][py] == 0)

            if opponent_count == 0:
                if player_count == 2 and empty_count == 1:
                    score += 5  # One move away from winning this board
                elif player_count == 1 and empty_count == 2:
                    score += 1
            elif player_count == 0:
                if opponent_count == 2 and empty_count == 1:
                    score -= 5  # Opponent one move away
                elif opponent_count == 1 and empty_count == 2:
                    score -= 1
        
        # Center and corner bonuses for small boards
        if small_board[1][1] == player:
            score += 2
        elif small_board[1][1] == opponent:
            score -= 2
        
        return score
    
    def _evaluateMetaBoard(self, board, player, opponent):
        """Evaluates the big board (3x3 grid of small boards)."""
        score = 0
        big_board = board.bigBoard
        
        lines = [
            # Rows
            [(0, 0), (0, 1), (0, 2)],
            [(1, 0), (1, 1), (1, 2)],
            [(2, 0), (2, 1), (2, 2)],
            # Columns
            [(0, 0), (1, 0), (2, 0)],
            [(0, 1), (1, 1), (2, 1)],
            [(0, 2), (1, 2), (2, 2)],
            # Diagonals
            [(0, 0), (1, 1), (2, 2)],
            [(0, 2), (1, 1), (2, 0)]
        ]
        
        for line in lines:
            player_count = sum(1 for bx, by in line if big_board[bx][by] == player)
            opponent_count = sum(1 for bx, by in line if big_board[bx][by] == opponent)
            empty_count = sum(1 for bx, by in line if big_board[bx][by] == 0)
            
            if opponent_count == 0:
                if player_count == 2 and empty_count == 1:
                    score += 50  # One board away from winning
                elif player_count == 1 and empty_count == 2:
                    score += 10
            elif player_count == 0:
                if opponent_count == 2 and empty_count == 1:
                    score -= 50  # Opponent one board away
                elif opponent_count == 1 and empty_count == 2:
                    score -= 10
        
        return score