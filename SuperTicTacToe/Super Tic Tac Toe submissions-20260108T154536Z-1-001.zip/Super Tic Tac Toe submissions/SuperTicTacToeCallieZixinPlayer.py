from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random

MINIMAX_DEPTH = 4 # Do not change this

class SuperTicTacToeCallieZixinPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("Callie and Zixin", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        opponent = board.players[1] if board.players[0] == player else board.players[0]
        winner = board.getGameEnded()
        if winner == player:
            return 1000
        elif winner == opponent:
            return -1000
        score = 0
        for x in range(3):
            for y in range(3):
                small = board.sub_boards[x][y]
                if small.winner == player:
                    score += 30
                elif small.winner == opponent:
                    score -= 30
                else:
                    score += self.evaluateLines(small, player, opponent)

        master = board.master_board
        if master.board[1][1] == player:
            score += 40
        elif master.board[1][1] == opponent:
            score -= 40
        score += self.evaluateLines(master, player, opponent) * 5
        return score
    def evaluateLines(self, board, player, opponent):
        lines = [
            [(0,0),(0,1),(0,2)],
            [(1,0),(1,1),(1,2)],
            [(2,0),(2,1),(2,2)],
            [(0,0),(1,0),(2,0)],
            [(0,1),(1,1),(2,1)],
            [(0,2),(1,2),(2,2)],
            [(0,0),(1,1),(2,2)],
            [(0,2),(1,1),(2,0)]
        ]
        score = 0
        for line in lines:
            p = 0
            o = 0
            e = 0
            for x, y in line:
                if board.board[x][y] == player:
                    p += 1
                elif board.board[x][y] == opponent:
                    o += 1
                else:
                    e += 1
            if o == 0:
                if p == 2 and e == 1:
                    score += 6
                elif p == 1 and e == 2:
                    score += 2
            elif p == 0:
                if o == 2 and e == 1:
                    score -= 6
                elif o == 1 and e == 2:
                    score -= 2
        return score