from MinimaxPlayer import MinimaxPlayer
from SuperTicTacToe.SuperTicTacToeMove import SuperTicTacToeMove
import random


MINIMAX_DEPTH = 4 # Do not change this

class SuperTicTacToeHARIANDCAMPlayer(MinimaxPlayer):
    def __init__(self):
        super().__init__("'Does anyone want this mint?' - C.H", MINIMAX_DEPTH)

    def scoreBoard(self, board, player):
        # if win board == 1
        # if lose board == -1
        #check if game over
        winner = board.getGameEnded()
        if winner!= False:
            if winner == player:
                return 1.0
            elif hasattr(winner, 'name') and winner.name == "Tie":
                return 0.0
            else:
                return -1.0
        
        score = 0.0
        opponent = board.players[1] if board.players[0] == player else board.players [0]

        #master board ts most important 
        master_score = self.evaluateSingleBoard(board.master_board, player, opponent)
        score += master_score * 0.4

        #sub boaard ts also important
        sub_board_score = 0.0
        won_boards = 0
        opponent_boards = 0
        for row in range(3):
            for col in range(3):
                sub_board = board.sub_boards[row][col]
                if sub_board.winner == player:
                    won_boards += 1
                elif sub_board.winner == opponent:
                    opponent_boards += 1
                else:
                    sub_board_score += self.evaluateSingleBoard(sub_board, player, opponent) * 0.02
        sub_board_score += (won_boards - opponent_boards) / 9.0 * 0.35
        score += sub_board_score

        #centner control
        center_board = board.sub_boards[1][1]
        if center_board.winner == player:
            score += .1
        elif center_board.winner == opponent:
            score -= .1
        elif center_board.board [1][1] == player:
            score += .03
        elif center_board.board [1][1] == opponent:
            score -= .03

        #corner control
        corners = [(0,0), (0,2), (2,0), (2,2)]
        corner_control = 0
        for r, c in corners:
            if board.sub_boards[r][c].winner == player:
                corner_control += 1
            elif board.sub_boards[r][c].winner == opponent:
                corner_control -= 1
        score += (corner_control / 4.0) * 0.08

        #general strategic posititoning
        if board.current_board is not None:
            if board.current_board.winner == opponent:
                score -= 0.07  # Forced into lost board
            elif board.current_board.is_full:
                score -= 0.04  # Forced into full board
        
        # Clamp to [-1, 1] range
        return max(-1.0, min(1.0, score))
    def evaluateSingleBoard(self, single_board, player, opponent):
        if single_board.winner == player:
            return 1.0
        if single_board.winner == opponent:
            return -1.0
        if single_board.is_full:
            return 0.0
        score = 0.0

        #check all lines
        lines = []
        
        #rows and columns
        for i in range(3):
            lines.append([single_board.board[i][j] for j in range(3)])  # rows
            lines.append([single_board.board[j][i] for j in range(3)])  # columns
        
        #diagonals
        lines.append([single_board.board[i][i] for i in range(3)])
        lines.append([single_board.board[i][2-i] for i in range(3)])
        
        #evaluate each line
        for line in lines:
            score += self.evaluateLine(line, player, opponent)
        
        #center control bonus for single board 
        if single_board.board[1][1] == player:
            score += 0.1
        elif single_board.board[1][1] == opponent:
            score -= 0.1
        
        #normalize by number of lines 
        return max(-1.0, min(1.0, score / 3.0))
    
    def evaluateLine(self, line, player, opponent):
        """
        Evaluates a single line (row, column, or diagonal).
        Returns a score contribution in range approximately [-0.5, 0.5]
        """
        player_count = line.count(player)
        opponent_count = line.count(opponent)
        empty_count = line.count(None)
        
        #blocked line
        if player_count > 0 and opponent_count > 0:
            return 0.0
        
        # Our potential
        if player_count > 0 and opponent_count == 0:
            if player_count == 2:
                return 0.5  #one move away
            elif player_count == 1:
                return 0.1  #two moves away
        
        #opponent potential
        if opponent_count > 0 and player_count == 0:
            if opponent_count == 2:
                return -0.5  #must block
            elif opponent_count == 1:
                return -0.1
        
        return 0.0

